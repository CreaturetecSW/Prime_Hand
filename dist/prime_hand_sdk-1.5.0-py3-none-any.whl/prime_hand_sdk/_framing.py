"""Private length-prefixed transport framing for Protocol V1."""

from __future__ import annotations

import struct


FRAME_HEADER_SIZE = 4
MAX_FRAME_SIZE = 64 * 1024
_LENGTH_STRUCT = struct.Struct("!I")


class FrameError(ValueError):
    """Base class for invalid length-prefixed frames."""


class InvalidFrameError(FrameError):
    """Raised when a frame has an invalid length field."""


class FrameTooLargeError(FrameError):
    """Raised when a frame exceeds the V1 maximum payload size."""


def encode_frame(payload: bytes | bytearray | memoryview) -> bytes:
    """Return one V1 frame containing *payload*."""

    if not isinstance(payload, (bytes, bytearray, memoryview)):
        raise TypeError("payload must be bytes-like")
    payload_bytes = bytes(payload)
    payload_size = len(payload_bytes)
    if payload_size == 0:
        raise InvalidFrameError("frame payload must not be empty")
    if payload_size > MAX_FRAME_SIZE:
        raise FrameTooLargeError(
            f"frame payload is {payload_size} bytes; maximum is {MAX_FRAME_SIZE}"
        )
    return _LENGTH_STRUCT.pack(payload_size) + payload_bytes


class FrameDecoder:
    """Incrementally decode split and sticky TCP reads."""

    def __init__(self, *, max_frame_size: int = MAX_FRAME_SIZE) -> None:
        if not 1 <= max_frame_size <= MAX_FRAME_SIZE:
            raise ValueError(
                f"max_frame_size must be in [1, {MAX_FRAME_SIZE}], "
                f"got {max_frame_size}"
            )
        self._max_frame_size = max_frame_size
        self._buffer = bytearray()

    def feed(self, data: bytes | bytearray | memoryview) -> tuple[bytes, ...]:
        """Consume one read chunk and return all complete payloads."""

        if not isinstance(data, (bytes, bytearray, memoryview)):
            raise TypeError("data must be bytes-like")
        self._buffer.extend(data)

        frames: list[bytes] = []
        while len(self._buffer) >= FRAME_HEADER_SIZE:
            payload_size = _LENGTH_STRUCT.unpack_from(self._buffer)[0]
            if payload_size == 0:
                raise InvalidFrameError("frame payload must not be empty")
            if payload_size > self._max_frame_size:
                raise FrameTooLargeError(
                    f"frame payload is {payload_size} bytes; "
                    f"maximum is {self._max_frame_size}"
                )

            frame_size = FRAME_HEADER_SIZE + payload_size
            if len(self._buffer) < frame_size:
                break

            frames.append(bytes(self._buffer[FRAME_HEADER_SIZE:frame_size]))
            del self._buffer[:frame_size]

        return tuple(frames)
