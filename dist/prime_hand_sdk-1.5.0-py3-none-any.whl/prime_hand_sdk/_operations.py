"""Handles for existing Runtime-owned operations; no SDK task executor."""

from __future__ import annotations
import threading
import time
from dataclasses import dataclass
from .errors import HandTimeoutError, OperationFailedError
from .models import OperationReason

_PROGRESS = (
    "unknown",
    "accepted",
    "waiting",
    "executing",
    "completed",
    "rejected",
    "failed",
    "cancelled",
    "timed_out",
)


@dataclass(frozen=True, slots=True)
class OperationResult:
    request_id: int
    kind: int
    progress: str
    reason_code: OperationReason = OperationReason.NONE
    detail: str = ""

    @property
    def terminal(self):
        return self.progress in (
            "completed",
            "rejected",
            "failed",
            "cancelled",
            "timed_out",
        )


class OperationHandle:
    def __init__(self, request_id, cancel, kind=0):
        self.request_id = request_id
        self._kind = kind
        self._cancel = cancel
        self._condition = threading.Condition()
        self._result = OperationResult(request_id, 0, "unknown")
        self._error = None

    @property
    def session_valid(self):
        with self._condition:
            return self._error is None

    @property
    def result(self):
        with self._condition:
            return self._result

    def _update(self, wire):
        if wire.request_id != self.request_id or (
            self._kind and wire.kind != self._kind
        ):
            raise ValueError("operation identity/kind mismatch")
        if not 0 < wire.progress < len(_PROGRESS):
            raise ValueError("invalid operation progress")
        with self._condition:
            if self._result.terminal:
                return
            self._result = OperationResult(
                wire.request_id,
                wire.kind,
                _PROGRESS[wire.progress],
                OperationReason(wire.reason_code),
                wire.detail,
            )
            self._condition.notify_all()

    def _fail(self, error):
        with self._condition:
            self._error = error
            self._condition.notify_all()

    def wait(self, timeout=30.0):
        if not isinstance(timeout, (int, float)) or not 0 < timeout < float("inf"):
            raise ValueError("timeout must be finite and positive")
        end = time.monotonic() + timeout
        with self._condition:
            while not self._result.terminal:
                if self._error:
                    raise self._error
                remaining = end - time.monotonic()
                if remaining <= 0:
                    raise HandTimeoutError(
                        f"waiting for operation {self.request_id} timed out; remote operation was not cancelled"
                    )
                self._condition.wait(remaining)
            result = self._result
        if result.progress != "completed":
            raise OperationFailedError(
                result.request_id, result.progress, result.reason_code, result.detail
            )
        return result

    def cancel(self, timeout=2.0):
        """Request remote cancellation. Already committed effects are retained."""
        if self.result.terminal:
            return self
        return self._cancel(self.request_id, timeout)
