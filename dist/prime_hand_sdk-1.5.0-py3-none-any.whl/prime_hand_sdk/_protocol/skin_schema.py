# Generated; do not edit.
SCHEMA_SHA256 = bytes.fromhex('c90ca93508cbb3b2da0a27a9f111ba5ad714399069ee4d8b115f555ed48886cd')
