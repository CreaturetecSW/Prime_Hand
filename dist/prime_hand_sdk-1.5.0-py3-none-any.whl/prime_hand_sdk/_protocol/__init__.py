"""Private generated Protocol V1 bundle shipped with the SDK."""
