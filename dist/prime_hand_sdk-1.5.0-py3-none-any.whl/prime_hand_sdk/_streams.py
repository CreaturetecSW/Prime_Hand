"""Bounded latest-value data readers; remote tasks remain Runtime-owned."""
from __future__ import annotations

from dataclasses import replace
import math
import threading
import time
from typing import Generic, TypeVar

from .errors import HandConnectionError, HandTimeoutError, InvalidStateError
from .models import StreamStatus, SubscriptionError, SubscriptionPhase

T = TypeVar("T")


def timeout_value(timeout):
    if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not math.isfinite(timeout) or timeout <= 0:
        raise ValueError("timeout must be finite and positive")
    return float(timeout)


class DataStream(Generic[T]):
    """One single-consumer unread slot, plus a non-consuming latest snapshot."""

    def __init__(self, kind, subscription_id=0, readiness_epoch=0):
        self._condition = threading.Condition()
        self._status = StreamStatus(kind, subscription_id, readiness_epoch=readiness_epoch)
        self._received_at = 0.0
        self._max_age = 0.1
        self._latest = None
        self._unread = False
        self._dropped = 0
        self._error = None
        self._closed = False
        self._on_close = None
        self._close_lock = threading.Lock()

    @property
    def status(self):
        with self._condition:
            return replace(self._status, stale=not self._received_at or time.monotonic()-self._received_at >= self._max_age)

    @property
    def latest(self):
        with self._condition:
            return self._latest if self._status.valid and not self._error and time.monotonic()-self._received_at < self._max_age else None

    @property
    def dropped_count(self):
        with self._condition:
            return self._dropped

    def _put(self, frame, source_age=0.0):
        with self._condition:
            if self._closed or not self._status.valid or source_age >= self._max_age:
                return
            if self._unread:
                self._dropped += 1
            self._received_at = time.monotonic() - max(0.0, source_age)
            self._latest, self._unread = frame, True
            self._status = replace(self._status, first_frame_received=True)
            self._condition.notify_all()

    def _update_status(self, status):
        with self._condition:
            if self._closed or self._error or self._status.phase is SubscriptionPhase.FAILED or status.subscription_id != self._status.subscription_id or status.readiness_epoch != self._status.readiness_epoch:
                return
            # Older telemetry must not undo a locally accepted cancellation.
            if status.request_id < self._status.request_id:
                return
            self._status = replace(status, first_frame_received=self._status.first_frame_received,
                valid=status.phase not in (SubscriptionPhase.FAILED, SubscriptionPhase.STOPPED))
            self._condition.notify_all()

    def _invalidate(self, error=None):
        with self._condition:
            if self._closed:
                return
            self._error = error or InvalidStateError("Runtime revoked the data subscription")
            self._status = replace(self._status, phase=SubscriptionPhase.FAILED,
                error=SubscriptionError.TRANSPORT if isinstance(error, HandConnectionError) else SubscriptionError.REVOKED, valid=False)
            self._condition.notify_all()

    def read(self, timeout=1.0):
        end = time.monotonic() + timeout_value(timeout)
        with self._condition:
            while True:
                if self._closed:
                    raise InvalidStateError("data stream is closed")
                if self._error:
                    raise self._error
                if not self._status.valid:
                    raise InvalidStateError(f"data subscription {self._status.phase.value}: {self._status.error.value}")
                if self._unread:
                    self._unread = False
                    if time.monotonic()-self._received_at < self._max_age:
                        return self._latest
                remaining = end - time.monotonic()
                if remaining <= 0:
                    return None
                self._condition.wait(remaining)

    def _stopping(self, request_id):
        with self._condition:
            if self._status.request_id == request_id and self._status.phase in (SubscriptionPhase.STOPPED, SubscriptionPhase.FAILED):
                return
            self._status = replace(self._status, request_id=request_id, phase=SubscriptionPhase.STOPPING)

    def _wait_stopped(self, timeout):
        end = time.monotonic() + timeout_value(timeout)
        with self._condition:
            while self._status.phase not in (SubscriptionPhase.STOPPED, SubscriptionPhase.FAILED):
                remaining = end - time.monotonic()
                if remaining <= 0:
                    raise HandTimeoutError("subscription stop was requested but not confirmed; close may be retried")
                self._condition.wait(remaining)
            if self._status.phase is SubscriptionPhase.FAILED:
                raise InvalidStateError(f"subscription stop failed: {self._status.error.value}")

    def close(self, timeout=2.0):
        timeout_value(timeout)
        with self._close_lock:
            if self._closed:
                return
            if self._on_close:
                self._on_close(timeout)  # A timeout leaves the object available to retry.
            self._finish()

    def _finish(self):
        with self._condition:
            self._closed = True
            phase = self._status.phase if self._status.phase is SubscriptionPhase.FAILED else SubscriptionPhase.STOPPED
            self._status = replace(self._status, valid=False, phase=phase)
            self._condition.notify_all()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, *_args):
        try:
            self.close()
        except Exception:
            if exc_type is None:
                raise
        return False


class JointStream(DataStream):
    """19101 joint data reader; never owns the persistent 19101 connection."""
