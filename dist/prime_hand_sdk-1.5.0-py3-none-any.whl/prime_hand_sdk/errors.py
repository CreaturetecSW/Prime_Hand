"""Exception hierarchy for the public Prime Hand SDK."""


class HandError(Exception):
    """Base class for all errors intentionally raised by the SDK."""


class HandConnectionError(HandError):
    """The SDK could not establish or maintain a hand connection."""


class HandTimeoutError(HandConnectionError):
    """An SDK operation exceeded its configured timeout."""


class ProtocolMismatchError(HandConnectionError):
    """The Runtime and SDK do not share a compatible protocol version."""


class DeviceBusyError(HandConnectionError):
    """Another client owns the hand's exclusive control lease."""


class ConnectionLostError(HandConnectionError):
    """An established hand connection was lost."""


class InvalidStateError(HandError):
    """The requested operation is not valid in the current hand state."""


class InvalidTargetError(HandError):
    """A joint target does not satisfy the public API contract."""


class HandFaultError(HandError):
    """Runtime reports an active hardware or system fault."""


class EmergencyStopError(HandError):
    """The hand is latched in or rejected because of Emergency Stop."""


__all__ = [
    "HandError",
    "RequestRejectedError",
    "HandConnectionError",
    "HandTimeoutError",
    "ProtocolMismatchError",
    "DeviceBusyError",
    "ConnectionLostError",
    "InvalidStateError",
    "InvalidTargetError",
    "HandFaultError",
    "EmergencyStopError",
]


class OperationFailedError(HandError):
    """Runtime operation reached a non-success terminal state."""

    def __init__(self, request_id: int, progress: str, reason_code: int, detail: str):
        self.request_id, self.progress, self.reason_code = (
            request_id,
            progress,
            reason_code,
        )
        super().__init__(
            f"operation {request_id}: {progress} ({reason_code}): {detail}"
        )


class RequestRejectedError(HandError):
    """A business request was rejected; the session can remain connected."""

    def __init__(self, detail, error_code=0, request_id=0):
        self.error_code, self.request_id = error_code, request_id
        super().__init__(detail)
