"""Private blocking TCP transport used during SDK session establishment."""

from __future__ import annotations

import socket
import time
from typing import Final

from google.protobuf.message import DecodeError

from ._framing import FrameDecoder, FrameError, encode_frame
from ._protocol import prime_hand_v1_pb2 as pb
from .errors import HandConnectionError, HandTimeoutError, ProtocolMismatchError


_RECV_SIZE: Final = 4096


class FramedSocket:
    """One blocking TCP socket carrying length-prefixed ``WireMessage`` data."""

    def __init__(self, socket_: socket.socket) -> None:
        self._socket = socket_
        self._decoder = FrameDecoder()
        self._pending_payloads: list[bytes] = []

    def close(self) -> None:
        try:
            self._socket.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        self._socket.close()

    def send(self, message: pb.WireMessage, deadline: float) -> None:
        try:
            self._socket.settimeout(_remaining_timeout(deadline))
            self._socket.sendall(encode_frame(message.SerializeToString()))
        except socket.timeout as error:
            raise HandTimeoutError("timed out while sending Protocol V1 message") from error
        except (OSError, FrameError) as error:
            raise HandConnectionError("failed to send Protocol V1 message") from error

    def receive(self, deadline: float) -> pb.WireMessage:
        while not self._pending_payloads:
            try:
                self._socket.settimeout(_remaining_timeout(deadline))
                chunk = self._socket.recv(_RECV_SIZE)
            except socket.timeout as error:
                raise HandTimeoutError(
                    "timed out while waiting for Protocol V1 message"
                ) from error
            except OSError as error:
                raise HandConnectionError(
                    "failed while receiving Protocol V1 message"
                ) from error
            if not chunk:
                raise HandConnectionError("Runtime closed the Protocol V1 connection")
            try:
                self._pending_payloads.extend(self._decoder.feed(chunk))
            except FrameError as error:
                raise ProtocolMismatchError("Runtime sent an invalid Protocol V1 frame") from error

        payload = self._pending_payloads.pop(0)
        message = pb.WireMessage()
        try:
            message.ParseFromString(payload)
        except DecodeError as error:
            raise ProtocolMismatchError(
                "Runtime sent an invalid Protocol V1 protobuf message"
            ) from error
        return message


def connect_tcp(ip: str, port: int, deadline: float) -> FramedSocket:
    """Open one TCP connection before the common initial-connect deadline."""

    try:
        socket_ = socket.create_connection((ip, port), timeout=_remaining_timeout(deadline))
    except socket.timeout as error:
        raise HandTimeoutError(f"timed out connecting to {ip}:{port}") from error
    except OSError as error:
        raise HandConnectionError(f"could not connect to {ip}:{port}") from error
    return FramedSocket(socket_)


def _remaining_timeout(deadline: float) -> float:
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise HandTimeoutError("SDK operation exceeded its timeout")
    return remaining
