"""Prime Hand session establishment for the synchronous Python SDK."""

from __future__ import annotations

import ipaddress
import math
import warnings
import logging
import threading
import time
from collections import deque
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field, replace
from typing import Final

from ._protocol import prime_hand_v1_pb2 as pb
from ._transport import FramedSocket, connect_tcp
from .errors import (
    ConnectionLostError,
    DeviceBusyError,
    EmergencyStopError,
    HandConnectionError,
    HandError,
    HandFaultError,
    HandTimeoutError,
    InvalidStateError,
    RequestRejectedError,
    InvalidTargetError,
    ProtocolMismatchError,
)
from ._operations import OperationHandle
from ._skin import SkinStream
from ._streams import JointStream
from .models import JointFrame, StreamStatus, SubscriptionPhase, SubscriptionError, OperationReason
from .models import (
    ModuleHealth,
    SystemPhase,
    ExecutionPhase,
    RuntimeStatus,
    HealthSummary,
    TargetReceipt,
    ControlLevel,
    DeviceInfo,
    EncoderLinkState,
    EncoderTelemetry,
    FaultInfo,
    HandState,
    InitializationState,
    InitializationTelemetry,
    JointControlMode,
    JointInfo,
    JointTelemetry,
    MotorTelemetry,
    ProtocolVersion,
    RuntimeState,
    TelemetryFrame,
    SkinChannel,
    SkinStatus,
)


class JointRangeWarning(UserWarning):
    """A target is outside the Runtime-reported joint range."""


_DEFAULT_IP: Final = "192.168.10.2"
_DEFAULT_CONTROL_PORT: Final = 19102
_DEFAULT_TELEMETRY_PORT: Final = 19101
_PROTOCOL_MAJOR: Final = 2
_PROTOCOL_MINOR: Final = 3
_SESSION_ID_SIZE: Final = 16
_INITIAL_RETRY_SECONDS: Final = 0.1
_TELEMETRY_RECEIVE_TIMEOUT_SECONDS: Final = 2.0
_SUBSCRIPTION_QUEUE_CAPACITY: Final = 64
_SDK_VERSION: Final = "1.5.0"
_LOGGER = logging.getLogger(__name__)


class PrimeHand:
    """One Prime Hand endpoint.

    Construction never performs network I/O. ``connect()`` establishes the
    paired V1 Control and Telemetry transports and binds them to one Runtime
    session. Control heartbeats and Telemetry reception are maintained in
    background threads; public lifecycle and control APIs are added later.
    """

    def __init__(
        self,
        ip: str = _DEFAULT_IP,
        control_port: int = _DEFAULT_CONTROL_PORT,
        telemetry_port: int = _DEFAULT_TELEMETRY_PORT,
    ) -> None:
        self._ip = _validate_ipv4(ip)
        self._control_port = _validate_port("control_port", control_port)
        self._telemetry_port = _validate_port("telemetry_port", telemetry_port)
        self._control: FramedSocket | None = None
        self._telemetry: FramedSocket | None = None
        self._session_id: bytes | None = None
        self._last_received_at = 0.0
        self._observer = False
        self._device_info: DeviceInfo | None = None
        self._control_worker: _ControlWorker | None = None
        self._telemetry_receiver: _TelemetryReceiver | None = None
        self._state_lock = threading.Condition()
        self._latest_state = HandState()
        self._latest_telemetry: TelemetryFrame | None = None
        self._subscriptions_lock = threading.Lock()
        self._subscriptions: list[_TelemetrySubscription] = []
        self._lifecycle_lock = threading.RLock()
        self._closing = False
        self._connection_failure: ConnectionLostError | None = None
        self._telemetry_failure: HandConnectionError | None = None
        self._skin_stream: SkinStream | None = None
        self._skin_opening = False
        self._joint_stream: JointStream | None = None
        self._joint_opening = False
        self._stream_counter = 0

    def connect(self, timeout: float = 5.0, *, observer: bool = False) -> None:
        """Establish paired Control and Telemetry V1 sessions.

        The initial TCP establishment retries only until this call's common
        deadline. It intentionally does not reconnect a session later if it
        is lost.
        """

        if self._control is not None or self._telemetry is not None:
            raise HandConnectionError("PrimeHand is already connected")
        if not isinstance(timeout, (int, float)) or timeout <= 0:
            raise ValueError("timeout must be a positive number of seconds")

        self._observer = bool(observer)
        deadline = time.monotonic() + float(timeout)
        last_error: HandConnectionError | None = None
        while True:
            control: FramedSocket | None = None
            telemetry: FramedSocket | None = None
            try:
                control = connect_tcp(self._ip, self._control_port, deadline)
                session_id, device_info = self._perform_control_hello(control, deadline)
                telemetry = connect_tcp(self._ip, self._telemetry_port, deadline)
                self._perform_telemetry_hello(telemetry, session_id, deadline)
            except (DeviceBusyError, ProtocolMismatchError):
                _close_transports(telemetry, control)
                raise
            except HandTimeoutError:
                _close_transports(telemetry, control)
                raise
            except HandConnectionError as error:
                last_error = error
                _close_transports(telemetry, control)
                if time.monotonic() >= deadline:
                    raise HandTimeoutError(
                        f"timed out connecting to Prime Hand at {self._ip}"
                    ) from last_error
                time.sleep(min(_INITIAL_RETRY_SECONDS, deadline - time.monotonic()))
                continue

            worker = _ControlWorker(
                transport=control,
                session_id=session_id,
                heartbeat_period_ms=device_info.heartbeat_period_ms,
                heartbeat_timeout_ms=device_info.heartbeat_timeout_ms,
                on_failure=self._mark_control_lost,
            )
            telemetry_receiver = _TelemetryReceiver(
                transport=telemetry,
                session_id=session_id,
                on_frame=self._record_telemetry,
                on_failure=self._mark_telemetry_stale,
            )
            self._control = control
            self._telemetry = telemetry
            self._session_id = session_id
            self._device_info = device_info
            self._control_worker = worker
            self._telemetry_receiver = telemetry_receiver
            self._connection_failure = None
            self._telemetry_failure = None
            worker.start()
            telemetry_receiver.start()
            return


    @property
    def device_info(self) -> DeviceInfo | None:
        """Static device identity and capabilities from the latest handshake."""

        with self._lifecycle_lock:
            return self._device_info

    @property
    def state(self) -> HandState:
        """Return the latest immutable Runtime state; safe before connection."""

        with self._state_lock:
            state = self._latest_state
            budget = (
                self._device_info.status_max_age_ms if self._device_info else 100
            ) / 1000
            elapsed = (
                max(0.0, time.monotonic() - self._last_received_at)
                if self._last_received_at
                else float("inf")
            )
            age_ns = state.status.age_ns + int(min(elapsed, 1e9) * 1e9)
            stale = state.stale or age_ns >= int(budget * 1e9) or not state.status.valid
            status = replace(
                state.status,
                valid=not stale,
                age_ns=age_ns,
            )
        return replace(state, stale=stale, status=status)

    def wait_ready(self, timeout: float = 30.0) -> None:
        """Wait for a fresh Telemetry state of ``READY``.

        Fault and Emergency Stop are terminal for this wait.  A Control link
        loss is never retried automatically and is reported immediately.
        """

        if not isinstance(timeout, (int, float)) or timeout <= 0:
            raise ValueError("timeout must be a positive number of seconds")
        with self._lifecycle_lock:
            if self._control is None and self._telemetry is None:
                if self._connection_failure is not None:
                    raise self._connection_failure
                raise HandConnectionError("PrimeHand is not connected")

        deadline = time.monotonic() + float(timeout)
        with self._state_lock:
            while True:
                state = self.state
                if state.status.control_ready and state.status.phase in (SystemPhase.READY, SystemPhase.RUNNING) and not state.stale:
                    return
                if state.status.phase is SystemPhase.FAULT:
                    raise HandFaultError(
                        "Runtime entered Fault while waiting for Ready"
                    )
                if state.status.phase is SystemPhase.EMERGENCY_STOP:
                    raise EmergencyStopError(
                        "Runtime entered Emergency Stop while waiting for Ready"
                    )
                if self._connection_failure is not None:
                    raise self._connection_failure
                if state.runtime_state is RuntimeState.PROTOCOL_MISMATCH:
                    raise ProtocolMismatchError("Runtime reported a protocol mismatch")
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise HandTimeoutError("timed out waiting for Prime Hand Ready")
                self._state_lock.wait(remaining if state.stale else min(remaining, 0.1))

    def __enter__(self) -> PrimeHand:
        self.connect()
        return self

    def __exit__(self, exc_type: object, exc_value: object, traceback: object) -> bool:
        try:
            self.close()
        except HandConnectionError:
            if exc_type is None:
                raise
        return False

    def close(self, timeout: float = 2.0) -> None:
        """Request Runtime Stop, then release both transports and background work."""

        if not isinstance(timeout, (int, float)) or timeout <= 0:
            raise ValueError("timeout must be a positive number of seconds")
        deadline = time.monotonic() + float(timeout)
        with self._lifecycle_lock:
            if self._closing:
                return
            control = self._control
            telemetry = self._telemetry
            worker = self._control_worker
            receiver = self._telemetry_receiver
            if control is None and telemetry is None:
                self._set_disconnected_state()
                return
            self._closing = True

        joint = self._joint_stream
        if joint is not None:
            try:
                joint.close(timeout=max(0.001, deadline-time.monotonic()))
            except HandError:
                joint._invalidate(ConnectionLostError("session closed before joint stop confirmation"))
                joint._finish()
            self._joint_stream = None
        skin = self._skin_stream
        if skin is not None:
            try:
                skin.close(timeout=max(0.001, deadline-time.monotonic()))
            except HandError:
                skin._invalidate(ConnectionLostError("session closed before skin stop confirmation"))
                skin.close(notify=False)  # Closing19103 revokes an uncertain remote task.
            self._skin_stream = None

        stop_error: HandConnectionError | None = None
        if worker is not None and not self._observer:
            try:
                worker.request_safe_stop_and_exit(deadline)
            except HandConnectionError as error:
                stop_error = error
            worker.request_stop()

        if worker is not None:
            worker.request_stop()
        self._close_all_subscriptions()
        _close_transports(telemetry, control)
        if worker is not None:
            worker.join(_remaining_seconds(deadline))
        if receiver is not None:
            receiver.join(_remaining_seconds(deadline))

        with self._lifecycle_lock:
            self._control = None
            self._telemetry = None
            self._control_worker = None
            self._telemetry_receiver = None
            self._session_id = None
            self._connection_failure = None
            self._telemetry_failure = None
            self._closing = False
            self._set_disconnected_state()
        if stop_error is not None:
            raise ConnectionLostError(
                "Runtime Stop could not be confirmed during close"
            ) from stop_error

    def set_joint_target(self, target_deg: Sequence[float]) -> int:
        """Submit one 22-joint degree target with latest-wins semantics."""
        try:
            values = tuple(target_deg)
        except TypeError as error:
            raise InvalidTargetError(
                "target_deg must be a sequence of 22 numbers"
            ) from error
        if len(values) != 22 or any(
            not isinstance(value, (int, float)) or not math.isfinite(value)
            for value in values
        ):
            raise InvalidTargetError(
                "target_deg must contain exactly 22 finite numbers"
            )
        info = self.device_info
        if info is not None and len(info.joints) == 22:
            for value, joint in zip(values, info.joints):
                if value < joint.min_position_deg or value > joint.max_position_deg:
                    warnings.warn(
                        f"{joint.name} target {value} deg is outside [{joint.min_position_deg}, {joint.max_position_deg}] deg; Runtime will clamp it",
                        JointRangeWarning,
                        stacklevel=2,
                    )
                    break
        return self._enqueue_joint_target(tuple(float(value) for value in values))

    def set_uniform_joint_control(
        self,
        mode: JointControlMode,
        level: ControlLevel | None = None,
        timeout: float = 2.0,
    ) -> int:
        """Configure all 22 joints and return the accepted profile identity."""
        _validate_joint_control_pair(mode, level)
        _validate_timeout(timeout)
        worker = self._control_worker
        if worker is None:
            raise HandConnectionError("PrimeHand is not connected")
        return worker.request_set_uniform_joint_control(
            mode,
            level,
            time.monotonic() + float(timeout),
        )

    def set_joint_control(
        self,
        controls: Mapping[int, tuple[JointControlMode, ControlLevel | None]],
        timeout: float = 2.0,
    ) -> int:
        """Set selected joints and return the accepted profile identity; omitted joints use PID2/MEDIUM.

        The mapping is sent as one atomic indexed command. An empty mapping
        selects the default PID2/MEDIUM setting for every joint.
        """
        try:
            items = tuple(controls.items())
        except AttributeError as error:
            raise ValueError(
                "controls must be a mapping of joint index to (mode, level)"
            ) from error
        indexed_controls: list[tuple[int, JointControlMode, ControlLevel | None]] = []
        for joint_index, setting in items:
            if (
                isinstance(joint_index, bool)
                or not isinstance(joint_index, int)
                or not 0 <= joint_index < 22
            ):
                raise ValueError(
                    f"joint index must be an integer in [0, 21]: {joint_index!r}"
                )
            try:
                mode, level = setting
            except (TypeError, ValueError) as error:
                raise ValueError(
                    f"control setting for joint {joint_index} must be (mode, level)"
                ) from error
            _validate_joint_control_pair(mode, level)
            indexed_controls.append((joint_index, mode, level))
        indexed_controls.sort(key=lambda entry: entry[0])
        _validate_timeout(timeout)
        worker = self._control_worker
        if worker is None:
            raise HandConnectionError("PrimeHand is not connected")
        info = self.device_info
        if info is not None and not info.supports_per_joint_control:
            raise ProtocolMismatchError(
                "Runtime does not advertise indexed per-joint control support"
            )
        return worker.request_set_joint_control(
            tuple(indexed_controls),
            time.monotonic() + float(timeout),
        )

    def stop(self, timeout: float = 2.0) -> None:
        """Request Runtime Stop while keeping the Control session connected."""
        self._request_action("stop", timeout)

    def emergency_stop(self, timeout: float = 1.0) -> None:
        """Request a latched Runtime Emergency Stop."""
        self._request_action("emergency_stop", timeout)

    def start(
        self,
        timeout: float = 30.0,
        *,
        wait: bool = True,
        execution_timeout: float = 30.0,
    ) -> OperationHandle:
        """Explicit Prepare; completion means Runtime prepared resources and reached Ready."""
        return self._system_operation(1, timeout, wait, execution_timeout)

    def standby(self, timeout: float = 30.0, *, wait: bool = True) -> OperationHandle:
        """Withdraw control and wait for Runtime's safe Standby completion."""
        return self._system_operation(2, timeout, wait, 30.0)

    def recover(self, timeout: float = 30.0, *, wait: bool = True) -> OperationHandle:
        """Recover to Standby. Call start explicitly before configuring control."""
        return self._system_operation(3, timeout, wait, 30.0)

    def _system_operation(self, kind, timeout, wait, execution_timeout, related=0):
        _validate_timeout(timeout)
        if (
            not isinstance(execution_timeout, (int, float))
            or not math.isfinite(execution_timeout)
            or not 1 <= execution_timeout <= 120
        ):
            raise ValueError("execution_timeout must be 1..120 seconds")
        worker = self._control_worker
        if worker is None or self._observer:
            raise InvalidStateError("operation requires an active Control session")
        if not self._device_info or not self._device_info.supports_system_operations:
            raise ProtocolMismatchError(
                "Runtime lacks explicit system operation capability"
            )
        end = time.monotonic() + timeout
        handle = worker.request_operation(
            kind,
            min(end, time.monotonic() + 2),
            round(execution_timeout * 1000),
            related,
        )
        if wait:
            handle.wait(max(0.000001, end - time.monotonic()))
        return handle

    def start_initialization(self, timeout: float = 2.0) -> OperationHandle:
        """Request the Runtime-owned whole-hand initialization sequence."""
        return self._system_operation(4, timeout, False, 120.0)

    def abort_initialization(self, timeout: float = 2.0) -> OperationHandle:
        """Abort Runtime initialization and release its output ownership."""
        return self._system_operation(5, timeout, False, 30.0)

    def _request_action(self, action: str, timeout: float) -> None:
        if not isinstance(timeout, (int, float)) or timeout <= 0:
            raise ValueError("timeout must be a positive number of seconds")
        worker = self._control_worker
        if worker is None:
            raise HandConnectionError("PrimeHand is not connected")
        worker.request_action(action, time.monotonic() + float(timeout))

    def configure_ip(
        self, ip: str, prefix_length: int = 24, timeout: float = 2.0
    ) -> None:
        target = _validate_ipv4(ip)
        if (
            isinstance(prefix_length, bool)
            or not isinstance(prefix_length, int)
            or not 1 <= prefix_length <= 30
        ):
            raise ValueError("prefix_length must be an integer in [1, 30]")
        if not isinstance(timeout, (int, float)) or timeout <= 0:
            raise ValueError("timeout must be a positive number of seconds")
        worker = self._control_worker
        if worker is None:
            raise HandConnectionError("PrimeHand is not connected")
        worker.request_configure_ip(
            target, prefix_length, time.monotonic() + float(timeout)
        )
        self._disconnect_after_reboot()

    def _disconnect_after_reboot(self) -> None:
        with self._lifecycle_lock:
            control, telemetry = self._control, self._telemetry
            self._closing = True
            self._control = self._telemetry = None
            self._control_worker = self._telemetry_receiver = None
            self._session_id = None
            self._set_disconnected_state()
            self._closing = False
        skin, self._skin_stream = self._skin_stream, None
        if skin is not None:
            skin.close(notify=False)
        self._close_all_subscriptions()
        _close_transports(telemetry, control)

    def _enqueue_joint_target(self, target_deg: tuple[float, ...]) -> int:
        """Place one already-validated target into the single latest-wins slot.

        This is intentionally private until the public target validation API is
        introduced in step 7.2.  A later target replaces any unsent one.
        """

        with self._lifecycle_lock:
            if self._connection_failure is not None:
                raise self._connection_failure
            worker = self._control_worker
        if worker is None:
            raise HandConnectionError("PrimeHand is not connected")
        return worker.enqueue_target(target_deg)

    def set_telemetry_subscription(self, enabled: bool = True, timeout: float = 2.0) -> bool:
        """Start/stop the session data task via 19102; receive data/status on 19101.

        Enabling requires a fresh prepared Runtime. Standby invalidates the task;
        callers must explicitly enable again after preparing. A local timeout
        does not cancel a request already transmitted; inspect data_subscribed.
        Observer connections may subscribe without acquiring a Control lease.
        """
        if self._joint_stream is not None:
            raise InvalidStateError("joint stream owns the subscription; close it instead")
        warnings.warn("set_telemetry_subscription is deprecated; use open_joint_stream", DeprecationWarning, stacklevel=2)
        if not isinstance(enabled, bool):
            raise TypeError("enabled must be bool")
        _validate_timeout(timeout)
        receiver = self._telemetry_receiver
        if receiver is None:
            raise HandConnectionError("PrimeHand is not connected")
        if not self._device_info or not self._device_info.supports_explicit_telemetry:
            raise ProtocolMismatchError("Runtime lacks explicit telemetry capability")
        state = self.state
        if enabled and (state.stale or not state.status.control_ready):
            raise InvalidStateError("telemetry data requires a fresh prepared Runtime")
        worker = self._control_worker
        if worker is None:
            raise HandConnectionError("19102 session is not connected")
        request = _SubscriptionRequest(enabled, state.status.readiness_epoch, time.monotonic() + timeout)
        worker._request_command(request, "subscription wait timed out; request not cancelled")
        return request.active

    @property
    def skin_status(self) -> SkinStatus | None:
        """Latest 19101 skin discovery and channel health, if available."""
        with self._state_lock:
            return self._latest_telemetry.skin_status if self._latest_telemetry else None

    def _request_skin_subscription(self, enabled: bool, timeout: float) -> bool:
        _validate_timeout(timeout)
        state = self.state
        if enabled and (state.stale or not state.status.control_ready):
            raise InvalidStateError("skin data requires a fresh prepared Runtime")
        worker = self._control_worker
        if worker is None:
            raise HandConnectionError("19102 session is not connected")
        request = _SubscriptionRequest(enabled, state.status.readiness_epoch,
            time.monotonic() + timeout, kind=pb.DATA_SUBSCRIPTION_SKIN)
        worker._request_command(request, "skin subscription wait timed out; request not cancelled")
        return request.active

    def _stream_identity(self):
        with self._lifecycle_lock:
            if self._closing or self._session_id is None or self._control_worker is None:
                raise HandConnectionError("PrimeHand is not connected")
            if not self._device_info or not self._device_info.supports_data_streams:
                raise ProtocolMismatchError("Runtime lacks the data-stream status capability")
            self._stream_counter += 1
            return self._stream_counter

    def _stream_request(self, stream, enabled, timeout):
        _validate_timeout(timeout)
        worker = self._control_worker
        if worker is None:
            raise HandConnectionError("19102 session is not connected")
        request = _SubscriptionRequest(enabled, stream.status.readiness_epoch,
            time.monotonic() + timeout, kind=0 if stream.status.kind == "joint" else 1,
            subscription_id=stream.status.subscription_id)
        worker._request_command(request, "subscription request timed out; remote request was not cancelled")
        if enabled and not request.active:
            raise InvalidStateError("Runtime did not accept the data subscription")
        return request.request_id

    def open_joint_stream(self, timeout: float = 2.0) -> JointStream:
        """Start a joint task, keeping the shared 19101 status receiver alive."""
        _validate_timeout(timeout)
        with self._lifecycle_lock:
            if self._joint_opening or self._joint_stream is not None:
                raise InvalidStateError("this session already has a joint stream")
            identity = self._stream_identity()
            state = self.state
            if state.stale or not state.status.control_ready:
                raise InvalidStateError("joint data requires a fresh prepared Runtime")
            self._joint_opening = True
            stream = JointStream("joint", identity, state.status.readiness_epoch)
            self._joint_stream = stream
            stream._on_close = lambda timeout: self._release_stream(stream, timeout)
        try:
            self._stream_request(stream, True, timeout)
            return stream
        except Exception as error:
            if isinstance(error, HandConnectionError):
                # Keep a handle if cancellation cannot be confirmed. Losing it
                # would hide an accepted task on the persistent19101 session.
                try:
                    stream.close(timeout=min(timeout, 1.0))
                except HandError:
                    error.stream = stream
                    raise error
            else:
                stream._finish()
                with self._lifecycle_lock:
                    self._joint_stream = None
            raise
        finally:
            with self._lifecycle_lock:
                self._joint_opening = False

    def open_skin_stream(self, timeout: float = 2.0) -> SkinStream:
        """Bind an independent 19103 receiver, then start its 19102 data task."""
        _validate_timeout(timeout)
        deadline = time.monotonic() + timeout
        with self._lifecycle_lock:
            if self._skin_opening or self._skin_stream is not None:
                raise InvalidStateError("this session already has a skin stream")
            identity = self._stream_identity()
            state, status = self.state, self.skin_status
            if state.stale or not state.status.control_ready:
                raise InvalidStateError("skin data requires a fresh prepared Runtime")
            if status is None or not status.installed or not status.data_port:
                raise InvalidStateError("Runtime does not expose installed skin")
            session = self._session_id
            self._skin_opening = True
        stream = None
        try:
            stream = SkinStream.connect(self._ip, status.data_port, session,
                max(0.001, deadline-time.monotonic()), subscription_id=identity,
                readiness_epoch=state.status.readiness_epoch)
            with self._lifecycle_lock:
                if self._closing or self._session_id != session:
                    raise HandConnectionError("session closed during skin handshake")
                self._skin_stream = stream
                stream._on_close = lambda timeout: self._release_stream(stream, timeout)
            self._stream_request(stream, True, max(0.001, deadline-time.monotonic()))
            return stream
        except Exception:
            if stream is not None:
                stream.close(notify=False)
            with self._lifecycle_lock:
                if self._skin_stream is stream:
                    self._skin_stream = None
            raise
        finally:
            with self._lifecycle_lock:
                self._skin_opening = False

    def _release_stream(self, stream, timeout):
        deadline = time.monotonic() + timeout
        # Already revoked by Fault/Standby/session loss: local release only.
        if stream.status.valid or stream.status.phase is SubscriptionPhase.STOPPING:
            request_id = self._stream_request(stream, False, timeout)
            stream._stopping(request_id)
            stream._wait_stopped(max(0.000001, deadline-time.monotonic()))
        with self._lifecycle_lock:
            if self._joint_stream is stream:
                self._joint_stream = None
            if self._skin_stream is stream:
                self._skin_stream = None

    def add_telemetry_callback(self, callback: Callable[[TelemetryFrame], None]) -> TelemetryCallback:
        """Listen locally to persistent 19101 frames; never start a data task."""
        return self._subscribe_telemetry(callback, capacity=1)

    def subscribe_telemetry(
        self, callback: Callable[[TelemetryFrame], None]
    ) -> TelemetrySubscription:
        """Subscribe to immutable Telemetry frames on an isolated callback thread."""
        warnings.warn("subscribe_telemetry is deprecated; use add_telemetry_callback", DeprecationWarning, stacklevel=2)
        return self._subscribe_telemetry(callback)

    def _subscribe_telemetry(
        self,
        callback: Callable[[TelemetryFrame], None],
        capacity: int = _SUBSCRIPTION_QUEUE_CAPACITY,
    ) -> _TelemetrySubscription:
        """Create one isolated telemetry subscription for the public API."""

        if not callable(callback):
            raise TypeError("callback must be callable")
        if self._telemetry_receiver is None:
            raise HandConnectionError("PrimeHand is not connected")
        subscription = _TelemetrySubscription(
            callback=callback,
            on_close=self._remove_subscription,
            capacity=capacity,
        )
        with self._subscriptions_lock:
            self._subscriptions.append(subscription)
        subscription.start()
        return subscription

    def _remove_subscription(self, subscription: _TelemetrySubscription) -> None:
        with self._subscriptions_lock:
            try:
                self._subscriptions.remove(subscription)
            except ValueError:
                pass

    def _record_telemetry(self, frame: TelemetryFrame) -> None:
        with self._state_lock:
            self._last_received_at = time.monotonic()
            self._latest_telemetry = frame
            self._latest_state = HandState(
                runtime_state=frame.runtime_state,
                status=frame.status,
                target_receipt=frame.target_receipt,
                data_subscribed=frame.data_subscribed,
                control_mode=frame.control_mode,
                control_level=frame.control_level,
                stale=False,
                sequence=frame.sequence,
                faults=frame.faults,
            )
            self._state_lock.notify_all()
        for stream in (self._joint_stream, self._skin_stream):
            if stream is None:
                continue
            matched = next((item for item in frame.subscriptions if item.kind == stream.status.kind and item.subscription_id == stream.status.subscription_id), None)
            if matched:
                stream._update_status(matched)
            if frame.status.valid and (frame.status.phase not in (SystemPhase.READY, SystemPhase.RUNNING) or frame.status.readiness_epoch != stream.status.readiness_epoch):
                stream._invalidate()
            if stream is self._joint_stream and frame.status.valid and frame.joints and frame.joint_subscription_id == stream.status.subscription_id and frame.status.readiness_epoch == stream.status.readiness_epoch:
                stream._put(JointFrame(frame.sequence, frame.joint_subscription_id, frame.status.readiness_epoch, frame.joints, frame.encoders), source_age=frame.status.age_ns/1_000_000_000)
        with self._subscriptions_lock:
            subscriptions = tuple(self._subscriptions)
        for subscription in subscriptions:
            subscription.enqueue(frame)

    def _close_all_subscriptions(self) -> None:
        with self._subscriptions_lock:
            subscriptions = tuple(self._subscriptions)
        for subscription in subscriptions:
            subscription.close()

    def _invalidate_streams(self, error=None):
        for stream in (self._joint_stream, self._skin_stream):
            if stream is not None:
                stream._invalidate(error)

    def _set_disconnected_state(self) -> None:
        self._invalidate_streams(ConnectionLostError("PrimeHand session closed"))
        self._joint_stream = None
        with self._state_lock:
            self._latest_state = HandState()
            self._latest_telemetry = None
            self._state_lock.notify_all()

    def _mark_control_lost(self, error: HandConnectionError) -> None:
        self._invalidate_streams(error)
        with self._lifecycle_lock:
            if self._closing or self._control is None:
                return
            self._connection_failure = ConnectionLostError(str(error))
            control = self._control
            telemetry = self._telemetry
            self._control = None
            self._telemetry = None
            self._session_id = None
            self._set_disconnected_state()
        skin, self._skin_stream = self._skin_stream, None
        if skin is not None:
            skin.close(notify=False)
        self._close_all_subscriptions()
        _close_transports(telemetry, control)

    def _mark_telemetry_stale(self, error: HandConnectionError) -> None:
        self._invalidate_streams(error)
        with self._lifecycle_lock:
            if self._closing:
                return
            telemetry = self._telemetry
        # A failed receiver must not leave an unread socket keeping a remote
        # joint task alive.19102 and control remain independent.
        with self._state_lock:
            state = self._latest_state
            self._latest_state = HandState(
                runtime_state=state.runtime_state,
                status=replace(state.status, valid=False),
                target_receipt=state.target_receipt,
                control_mode=state.control_mode,
                control_level=state.control_level,
                stale=True,
                sequence=state.sequence,
                faults=state.faults,
            )
            self._telemetry_failure = error
            self._state_lock.notify_all()
        _close_transports(telemetry)

    def _perform_control_hello(
        self,
        transport: FramedSocket,
        deadline: float,
    ) -> tuple[bytes, DeviceInfo]:
        request = _client_hello(channel=pb.CHANNEL_CONTROL, session_id=b"")
        request.client_hello.requested_role = pb.SESSION_ROLE_OBSERVER if self._observer else pb.SESSION_ROLE_CONTROL
        transport.send(request, deadline)
        response = transport.receive(deadline)
        hello = _require_server_hello(response, expected_session_id=None)
        session_id = bytes(response.session_id)
        if len(session_id) != _SESSION_ID_SIZE:
            raise ProtocolMismatchError(
                "Control ServerHello did not contain a 128-bit session_id"
            )
        if hello.granted_role != (pb.SESSION_ROLE_OBSERVER if self._observer else pb.SESSION_ROLE_CONTROL):
            raise ProtocolMismatchError(
                "Control ServerHello did not grant the requested control role"
            )
        device_info = _device_info_from_hello(hello)
        _validate_heartbeat_parameters(device_info)
        return session_id, device_info

    def _perform_telemetry_hello(
        self,
        transport: FramedSocket,
        session_id: bytes,
        deadline: float,
    ) -> None:
        request = _client_hello(channel=pb.CHANNEL_TELEMETRY, session_id=session_id)
        request.client_hello.requested_role = pb.SESSION_ROLE_OBSERVER if self._observer else pb.SESSION_ROLE_CONTROL
        transport.send(request, deadline)
        response = transport.receive(deadline)
        hello = _require_server_hello(response, expected_session_id=session_id)
        if hello.granted_role != (pb.SESSION_ROLE_OBSERVER if self._observer else pb.SESSION_ROLE_CONTROL):
            raise ProtocolMismatchError(
                "Telemetry ServerHello did not preserve the control role"
            )


@dataclass(slots=True)
class _SafeStopRequest:
    deadline: float
    completed: threading.Event = field(default_factory=threading.Event)
    error: HandConnectionError | None = None


@dataclass(slots=True)
class _SetControlRequest:
    mode: JointControlMode | None
    level: ControlLevel | None
    joint_controls: tuple[tuple[int, JointControlMode, ControlLevel | None], ...] = ()
    indexed: bool = False
    profile_id: int = 0
    deadline: float = 0.0
    completed: threading.Event = field(default_factory=threading.Event)
    error: HandError | None = None


@dataclass(slots=True)
class _ActionRequest:
    action: str
    deadline: float
    completed: threading.Event = field(default_factory=threading.Event)
    error: HandError | None = None


@dataclass(slots=True)
class _ConfigureRequest:
    ip: str
    prefix_length: int
    deadline: float
    completed: threading.Event = field(default_factory=threading.Event)
    error: HandError | None = None


@dataclass(slots=True)
class _SubscriptionRequest:
    enabled: bool
    epoch: int
    deadline: float
    kind: int = pb.DATA_SUBSCRIPTION_JOINT
    subscription_id: int = 0
    request_id: int = 0
    active: bool = False
    completed: threading.Event = field(default_factory=threading.Event)
    error: HandError | None = None


@dataclass(slots=True)
class _OperationRequest:
    kind: int
    deadline: float
    execution_timeout_ms: int
    related: int = 0
    completed: threading.Event = field(default_factory=threading.Event)
    error: HandError | None = None
    handle: OperationHandle | None = None


_ControlCommand = (
    _SetControlRequest | _ActionRequest | _ConfigureRequest | _OperationRequest | _SubscriptionRequest
)


@dataclass(frozen=True, slots=True)
class _PendingTarget:
    sequence: int
    target_deg: tuple[float, ...]
    profile_id: int = 0


class _ControlWorker:
    """The sole Control-socket writer for heartbeats, commands and targets."""

    def __init__(
        self,
        *,
        transport: FramedSocket,
        session_id: bytes,
        heartbeat_period_ms: int,
        heartbeat_timeout_ms: int,
        on_failure: Callable[[HandConnectionError], None],
    ) -> None:
        self._transport = transport
        self._session_id = session_id
        self._heartbeat_period_s = heartbeat_period_ms / 1000.0
        self._heartbeat_timeout_s = heartbeat_timeout_ms / 1000.0
        self._condition = threading.Condition()
        self._stopping = False
        self._pending_target: _PendingTarget | None = None
        self._profile_id = 0
        self._operations: dict[int, OperationHandle] = {}
        self._next_target_sequence = 1
        self._next_message_sequence = 2
        self._next_heartbeat_sequence = 1
        self._failure: HandConnectionError | None = None
        self._on_failure = on_failure
        self._safe_stop_request: _SafeStopRequest | None = None
        self._command_queue: deque[_ControlCommand] = deque()
        self._thread = threading.Thread(
            target=self._run,
            name="prime-hand-control",
            daemon=True,
        )

    @property
    def failure(self) -> HandConnectionError | None:
        """Return a terminal worker error for later public error propagation."""

        with self._condition:
            return self._failure

    def start(self) -> None:
        self._thread.start()

    def request_stop(self) -> None:
        with self._condition:
            self._stopping = True
            for handle in tuple(self._operations.values()):
                handle._fail(
                    ConnectionLostError(
                        "Control session closed; remote outcome may be unavailable"
                    )
                )
            self._fail_queued_commands(
                HandConnectionError("PrimeHand Control worker is stopping")
            )
            self._condition.notify_all()

    def request_safe_stop_and_exit(self, deadline: float) -> None:
        request = _SafeStopRequest(deadline=deadline)
        with self._condition:
            if self._failure is not None:
                raise self._failure
            if self._stopping:
                raise HandConnectionError("PrimeHand Control worker is stopping")
            self._safe_stop_request = request
            self._fail_queued_commands(
                HandConnectionError("PrimeHand Control worker is stopping")
            )
            self._condition.notify_all()
        if not request.completed.wait(_remaining_seconds(deadline)):
            raise HandTimeoutError("timed out waiting for Runtime Stop during close")
        if request.error is not None:
            raise request.error

    def request_set_uniform_joint_control(
        self, mode: JointControlMode, level: ControlLevel | None, deadline: float
    ) -> int:
        request = _SetControlRequest(mode=mode, level=level, deadline=deadline)
        self._request_command(request, "timed out setting uniform joint control")
        return request.profile_id

    def request_set_joint_control(
        self,
        controls: tuple[tuple[int, JointControlMode, ControlLevel | None], ...],
        deadline: float,
    ) -> int:
        request = _SetControlRequest(mode=None, level=None, joint_controls=controls,
                                     indexed=True, deadline=deadline)
        self._request_command(request, "timed out setting per-joint control")
        return request.profile_id

    def request_action(self, action: str, deadline: float) -> None:
        self._request_command(
            _ActionRequest(action=action, deadline=deadline),
            f"timed out requesting {action}",
        )

    def request_configure_ip(
        self, ip: str, prefix_length: int, deadline: float
    ) -> None:
        self._request_command(
            _ConfigureRequest(ip=ip, prefix_length=prefix_length, deadline=deadline),
            "timed out configuring IPv4",
        )

    def _request_command(self, request: _ControlCommand, timeout_message: str) -> None:
        with self._condition:
            if self._failure is not None:
                raise self._failure
            if self._stopping:
                raise HandConnectionError("PrimeHand Control worker is stopping")
            self._command_queue.append(request)
            self._condition.notify_all()
        if not request.completed.wait(_remaining_seconds(request.deadline)):
            with self._condition:
                try:
                    self._command_queue.remove(request)
                except ValueError:
                    pass
            raise HandTimeoutError(timeout_message)
        if request.error is not None:
            raise request.error

    def _fail_queued_commands(self, error: HandConnectionError) -> None:
        while self._command_queue:
            request = self._command_queue.popleft()
            request.error = error
            request.completed.set()

    def join(self, timeout: float) -> None:
        self._thread.join(timeout=max(0.0, timeout))

    def enqueue_target(self, target_deg: tuple[float, ...]) -> int:
        with self._condition:
            if self._stopping:
                raise HandConnectionError("PrimeHand Control worker is stopping")
            if not self._profile_id:
                raise InvalidStateError(
                    "configure control successfully before sending a target"
                )
            sequence = self._next_target_sequence
            self._next_target_sequence += 1
            self._pending_target = _PendingTarget(
                sequence, tuple(target_deg), self._profile_id
            )
            self._condition.notify_all()
            return sequence

    def _run(self) -> None:
        next_heartbeat_at = time.monotonic()
        active_stop_request: _SafeStopRequest | None = None
        active_command: _ControlCommand | None = None
        try:
            while True:
                pending_target, heartbeat_due, active_stop_request, active_command = (
                    self._wait_for_work(next_heartbeat_at)
                )
                if active_stop_request is not None:
                    self._send_stop(active_stop_request.deadline)
                    active_stop_request.completed.set()
                    return
                if heartbeat_due:
                    self._send_heartbeat()
                    next_heartbeat_at = time.monotonic() + self._heartbeat_period_s
                if active_command is not None:
                    try:
                        self._send_command(active_command)
                    except HandConnectionError:
                        raise
                    except HandError as error:
                        active_command.error = error
                    active_command.completed.set()
                    if (
                        isinstance(active_command, _ConfigureRequest)
                        and active_command.error is None
                    ):
                        return
                    active_command = None
                    continue
                if pending_target is not None:
                    self._send_target(pending_target)
                    continue
                if not heartbeat_due:
                    return
        except HandConnectionError as error:
            with self._condition:
                self._failure = error
                self._stopping = True
                if active_stop_request is None:
                    active_stop_request = self._safe_stop_request
                if active_stop_request is not None:
                    active_stop_request.error = error
                    active_stop_request.completed.set()
                if active_command is not None:
                    active_command.error = error
                    active_command.completed.set()
                self._fail_queued_commands(error)
                self._condition.notify_all()
            for handle in self._operations.values():
                handle._fail(error)
            self._on_failure(error)

    def _wait_for_work(
        self,
        next_heartbeat_at: float,
    ) -> tuple[
        _PendingTarget | None, bool, _SafeStopRequest | None, _ControlCommand | None
    ]:
        with self._condition:
            while not self._stopping:
                if self._safe_stop_request is not None:
                    request = self._safe_stop_request
                    self._safe_stop_request = None
                    return None, False, request, None
                now = time.monotonic()
                if now >= next_heartbeat_at:
                    return None, True, None, None
                if self._command_queue:
                    return None, False, None, self._command_queue.popleft()
                if self._pending_target is not None:
                    pending_target = self._pending_target
                    self._pending_target = None
                    return pending_target, False, None, None
                self._condition.wait(timeout=next_heartbeat_at - now)
            return None, False, None, None

    def _send_command(self, request: _ControlCommand) -> None:
        if isinstance(request, _SubscriptionRequest):
            message = self._new_message()
            message.telemetry_subscription_request.enabled = request.enabled
            message.telemetry_subscription_request.readiness_epoch = request.epoch
            message.telemetry_subscription_request.kind = request.kind
            message.telemetry_subscription_request.subscription_id = request.subscription_id
            request.request_id = message.message_sequence
            self._transport.send(message, request.deadline)
            response = self._receive_control(request.deadline, message.message_sequence)
            if response.message_sequence != message.message_sequence or response.WhichOneof("payload") != "telemetry_subscription_response":
                raise ProtocolMismatchError("subscription result identity mismatch")
            _raise_operation_error(response.telemetry_subscription_response.status, "Runtime rejected telemetry subscription")
            if response.telemetry_subscription_response.kind != request.kind:
                raise ProtocolMismatchError("subscription result kind mismatch")
            if request.subscription_id and response.telemetry_subscription_response.subscription_id != request.subscription_id:
                raise ProtocolMismatchError("subscription id mismatch")
            request.active = response.telemetry_subscription_response.active
            return
        if isinstance(request, _OperationRequest):
            self._send_operation(request)
            return
        if isinstance(request, _SetControlRequest):
            self._send_set_joint_control(request)
        elif isinstance(request, _ActionRequest):
            self._send_action(request)
        elif isinstance(request, _ConfigureRequest):
            self._send_configure_ip(request)
        else:  # pragma: no cover - exhaustiveness guard for future command types
            raise HandConnectionError("unknown PrimeHand Control command")

    def request_operation(self, kind, deadline, execution_timeout_ms, related=0):
        request = _OperationRequest(kind, deadline, execution_timeout_ms, related)
        self._request_command(
            request, "timed out waiting for Runtime operation acceptance"
        )
        return request.handle

    def _receive_control(self, deadline, request_id=None):
        while True:
            message = self._transport.receive(deadline)
            _validate_session_message(message, self._session_id)
            if message.WhichOneof("payload") == "protocol_error" and request_id is not None:
                if message.protocol_error.request_id not in (0, request_id):
                    raise ProtocolMismatchError("protocol rejection identity mismatch")
                _raise_protocol_error(message.protocol_error, business=True)
            if message.WhichOneof("payload") != "operation_update":
                return message
            update = message.operation_update
            if update.request_id != message.message_sequence:
                raise ProtocolMismatchError("operation result identity mismatch")
            handle = self._operations.get(update.request_id)
            if handle:
                try:
                    handle._update(update)
                except ValueError as error:
                    raise ProtocolMismatchError(str(error)) from error
                if handle.result.terminal:
                    self._operations.pop(update.request_id, None)

    def _send_operation(self, request):
        with self._condition:
            if request.kind in (1, 2, 3, 6):
                self._pending_target = None
            if request.kind in (2, 3, 6):
                self._profile_id = 0
        message = self._new_message()
        message.system_operation_request.kind = request.kind
        message.system_operation_request.execution_timeout_ms = (
            request.execution_timeout_ms
        )
        message.system_operation_request.related_request_id = request.related
        handle = OperationHandle(
            message.message_sequence,
            lambda request_id, timeout: self.request_operation(
                5 if request.kind == 4 else 6,
                time.monotonic() + timeout,
                30000,
                request_id,
            ),
            kind=request.kind,
        )
        self._operations[message.message_sequence] = handle
        self._transport.send(message, request.deadline)
        # Only acceptance is awaited here. Long execution never occupies the worker.
        while handle.result.progress == "unknown":
            response = self._transport.receive(request.deadline)
            _validate_session_message(response, self._session_id)
            if response.WhichOneof("payload") == "protocol_error":
                self._operations.pop(handle.request_id, None)
                if response.protocol_error.request_id not in (0, handle.request_id):
                    raise ProtocolMismatchError("operation rejection identity mismatch")
                _raise_protocol_error(response.protocol_error, business=True)
            if response.WhichOneof("payload") != "operation_update":
                raise ProtocolMismatchError("expected operation update")
            update = response.operation_update
            target = self._operations.get(update.request_id)
            if target:
                target._update(update)
        request.handle = handle
        if handle.result.terminal:
            self._operations.pop(handle.request_id, None)
            handle.wait(0.001)

    def _send_heartbeat(self) -> None:
        heartbeat_sequence = self._next_heartbeat_sequence
        self._next_heartbeat_sequence += 1
        message = self._new_message()
        message.heartbeat.sequence = heartbeat_sequence
        deadline = time.monotonic() + min(
            self._heartbeat_period_s,
            self._heartbeat_timeout_s,
        )
        self._transport.send(message, deadline)
        response = self._receive_control(deadline)
        _validate_session_message(response, self._session_id)
        payload_name = response.WhichOneof("payload")
        if payload_name == "protocol_error":
            _raise_protocol_error(response.protocol_error)
        if payload_name != "heartbeat_ack":
            raise ProtocolMismatchError(
                f"expected HeartbeatAck, received {payload_name or 'an empty message'}"
            )
        if response.heartbeat_ack.sequence != heartbeat_sequence:
            raise ProtocolMismatchError(
                "Runtime returned HeartbeatAck with an unexpected sequence"
            )

    def _send_target(self, target: _PendingTarget) -> None:
        message = self._new_message()
        message.set_joint_target.profile_id = target.profile_id
        message.set_joint_target.target_sequence = target.sequence
        message.set_joint_target.target_deg.extend(target.target_deg)
        deadline = time.monotonic() + min(
            self._heartbeat_period_s,
            self._heartbeat_timeout_s,
        )
        self._transport.send(message, deadline)

    def _send_set_joint_control(self, request: _SetControlRequest) -> None:
        with self._condition:
            self._pending_target = None
            self._profile_id = 0
        message = self._new_message()
        mapping = {
            JointControlMode.OPEN_LOOP: pb.CONTROL_MODE_OPEN_LOOP,
            JointControlMode.PID1: pb.CONTROL_MODE_PID1,
            JointControlMode.PID2: pb.CONTROL_MODE_PID2,
        }
        levels = {
            None: pb.CONTROL_LEVEL_UNSPECIFIED,
            ControlLevel.LOW: pb.CONTROL_LEVEL_LOW,
            ControlLevel.MEDIUM: pb.CONTROL_LEVEL_MEDIUM,
            ControlLevel.HIGH: pb.CONTROL_LEVEL_HIGH,
        }
        if request.indexed:
            # An empty indexed mapping still needs to mark the protobuf
            # oneof payload as present; otherwise Runtime sees an empty frame.
            message.set_joint_control_request.SetInParent()
            for joint_index, mode, level in request.joint_controls:
                setting = message.set_joint_control_request.joint_controls.add()
                setting.joint_index = joint_index
                setting.mode = mapping[mode]
                setting.level = levels[level]
        else:
            message.set_joint_control_request.mode = mapping[request.mode]
            message.set_joint_control_request.level = levels[request.level]
        self._transport.send(message, request.deadline)
        response = self._receive_control(request.deadline, message.message_sequence)
        if response.message_sequence != message.message_sequence:
            raise ProtocolMismatchError("response request identity mismatch")
        _validate_session_message(response, self._session_id)
        if response.WhichOneof("payload") != "set_joint_control_response":
            raise HandConnectionError(
                "Runtime returned an unexpected joint control response"
            )
        _raise_operation_error(
            response.set_joint_control_response.status,
            "Runtime rejected joint control request",
        )
        if response.message_sequence != message.message_sequence:
            raise ProtocolMismatchError("configuration response identity mismatch")
        if not response.set_joint_control_response.profile_id:
            raise ProtocolMismatchError("configuration response lacks profile identity")
        with self._condition:
            self._profile_id = response.set_joint_control_response.profile_id
            request.profile_id = self._profile_id
        if (
            request.indexed
            and len(response.set_joint_control_response.joint_controls) != 22
        ):
            raise ProtocolMismatchError(
                "Runtime indexed joint control response did not contain 22 resolved settings"
            )

    def _send_action(self, request: _ActionRequest) -> None:
        with self._condition:
            self._pending_target = None
            self._profile_id = 0
        message = self._new_message()
        expected = {
            "stop": "stop_response",
            "emergency_stop": "emergency_stop_response",
            "recover": "recover_response",
            "initialization_start": "initialization_start_response",
            "initialization_abort": "initialization_abort_response",
        }
        try:
            payload_name = expected[request.action]
        except KeyError as error:
            raise HandConnectionError(
                f"unknown Runtime action {request.action}"
            ) from error
        getattr(message, f"{request.action}_request").SetInParent()
        self._transport.send(message, request.deadline)
        response = self._receive_control(request.deadline, message.message_sequence)
        if response.message_sequence != message.message_sequence:
            raise ProtocolMismatchError("response request identity mismatch")
        _validate_session_message(response, self._session_id)
        if response.WhichOneof("payload") == "protocol_error":
            _raise_protocol_error(response.protocol_error)
        if response.WhichOneof("payload") != payload_name:
            raise HandConnectionError(
                f"Runtime returned an unexpected {request.action} response"
            )
        _raise_operation_error(
            getattr(response, payload_name).status,
            f"Runtime rejected {request.action}",
        )

    def _send_configure_ip(self, request: _ConfigureRequest) -> None:
        message = self._new_message()
        message.configure_ipv4_request.target_ipv4 = request.ip
        message.configure_ipv4_request.prefix_length = request.prefix_length
        self._transport.send(message, request.deadline)
        response = self._receive_control(request.deadline, message.message_sequence)
        if response.message_sequence != message.message_sequence:
            raise ProtocolMismatchError("response request identity mismatch")
        _validate_session_message(response, self._session_id)
        if response.WhichOneof("payload") != "configure_ipv4_response":
            raise HandConnectionError("Runtime rejected IPv4 configuration")
        result = response.configure_ipv4_response
        if result.result in (pb.CONFIGURE_IPV4_REJECTED_INVALID_ADDRESS, pb.CONFIGURE_IPV4_REJECTED_INVALID_PREFIX):
            raise InvalidTargetError(result.detail or "Runtime rejected IPv4 parameters")
        elif result.result == pb.CONFIGURE_IPV4_REJECTED_STATE:
            raise InvalidStateError(result.detail or "Runtime rejected IPv4 configuration in this state")
        elif result.result == pb.CONFIGURE_IPV4_REJECTED_PERSISTENCE:
            raise RequestRejectedError(result.detail or "Runtime could not persist IPv4 configuration", pb.ERROR_CODE_IP_PERSISTENCE_FAILED)
        if (
            result.result != pb.CONFIGURE_IPV4_ACCEPTED_REBOOT_REQUIRED
            or not result.persisted
            or not result.reboot_required
        ):
            raise ProtocolMismatchError(
                result.detail or "inconsistent IPv4 configuration result"
            )

    def _send_stop(self, deadline: float) -> None:
        with self._condition:
            self._pending_target = None
            self._profile_id = 0
        message = self._new_message()
        message.stop_request.SetInParent()
        self._transport.send(message, deadline)
        response = self._receive_control(deadline)
        _validate_session_message(response, self._session_id)
        payload_name = response.WhichOneof("payload")
        if payload_name == "protocol_error":
            _raise_protocol_error(response.protocol_error)
        if payload_name != "stop_response":
            raise HandConnectionError(
                "Runtime returned an unexpected Stop response during close"
            )
        if not response.stop_response.status.ok:
            raise HandConnectionError(
                response.stop_response.status.detail
                or "Runtime rejected Stop during close"
            )

    def _new_message(self) -> pb.WireMessage:
        message = pb.WireMessage(
            protocol_major=_PROTOCOL_MAJOR,
            protocol_minor=_PROTOCOL_MINOR,
            session_id=self._session_id,
            message_sequence=self._next_message_sequence,
        )
        self._next_message_sequence += 1
        return message


class _TelemetryReceiver:
    """Read V1 telemetry independently from Control and callback execution."""

    def __init__(
        self,
        *,
        transport: FramedSocket,
        session_id: bytes,
        on_frame: Callable[[TelemetryFrame], None],
        on_failure: Callable[[HandConnectionError], None],
    ) -> None:
        self._transport = transport
        self._session_id = session_id
        self._on_frame = on_frame
        self._on_failure = on_failure
        self._failure: HandConnectionError | None = None
        self._thread = threading.Thread(
            target=self._run,
            name="prime-hand-telemetry-receive",
            daemon=True,
        )

    @property
    def failure(self) -> HandConnectionError | None:
        return self._failure

    def start(self) -> None:
        self._thread.start()

    def _run(self) -> None:
        try:
            last_frame = time.monotonic()
            while True:
                try:
                    message = self._transport.receive(time.monotonic() + 0.1)
                except HandTimeoutError:
                    if time.monotonic() - last_frame < _TELEMETRY_RECEIVE_TIMEOUT_SECONDS:
                        continue
                    raise
                _validate_session_message(message, self._session_id)
                payload_name = message.WhichOneof("payload")
                if payload_name == "protocol_error":
                    _raise_protocol_error(message.protocol_error)
                if payload_name != "telemetry_frame":
                    raise ProtocolMismatchError(
                        "expected TelemetryFrame, received "
                        f"{payload_name or 'an empty message'}"
                    )
                last_frame = time.monotonic()
                self._on_frame(_telemetry_frame_from_wire(message.telemetry_frame))
        except HandConnectionError as error:
            self._failure = error
            self._on_failure(error)

    def join(self, timeout: float) -> None:
        self._thread.join(timeout=max(0.0, timeout))


class _TelemetrySubscription:
    """One bounded telemetry queue and isolated callback dispatcher."""

    def __init__(
        self,
        *,
        callback: Callable[[TelemetryFrame], None],
        on_close: Callable[[_TelemetrySubscription], None],
        capacity: int = _SUBSCRIPTION_QUEUE_CAPACITY,
    ) -> None:
        self._capacity = capacity
        self._callback = callback
        self._on_close = on_close
        self._condition = threading.Condition()
        self._queue: deque[TelemetryFrame] = deque()
        self._closed = False
        self._dropped_count = 0
        self._thread = threading.Thread(
            target=self._run,
            name="prime-hand-telemetry-callback",
            daemon=True,
        )

    @property
    def dropped_count(self) -> int:
        with self._condition:
            return self._dropped_count

    def start(self) -> None:
        self._thread.start()

    def __enter__(self) -> TelemetrySubscription:
        return self

    def __exit__(self, exc_type: object, exc_value: object, traceback: object) -> bool:
        self.close()
        return False

    def close(self) -> None:
        with self._condition:
            if self._closed:
                return
            self._closed = True
            self._condition.notify_all()
        self._on_close(self)

    def enqueue(self, frame: TelemetryFrame) -> None:
        with self._condition:
            if self._closed:
                return
            if len(self._queue) >= self._capacity:
                self._queue.popleft()
                self._dropped_count += 1
            self._queue.append(frame)
            self._condition.notify()

    def _run(self) -> None:
        while True:
            with self._condition:
                while not self._closed and not self._queue:
                    self._condition.wait()
                if self._closed:
                    return
                frame = self._queue.popleft()
            try:
                self._callback(frame)
            except Exception:
                _LOGGER.exception("Prime Hand telemetry callback raised an exception")


TelemetrySubscription = _TelemetrySubscription
TelemetryCallback = _TelemetrySubscription


def _validate_joint_control_pair(
    mode: JointControlMode,
    level: ControlLevel | None,
) -> None:
    if not isinstance(mode, JointControlMode):
        raise ValueError("mode must be a JointControlMode")
    if mode is JointControlMode.OPEN_LOOP:
        if level is not None:
            raise ValueError("OPEN_LOOP does not accept a control level")
    elif not isinstance(level, ControlLevel):
        raise ValueError("PID1 and PID2 require a ControlLevel")


def _validate_timeout(timeout: float) -> None:
    if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not math.isfinite(timeout) or timeout <= 0:
        raise ValueError("timeout must be finite and positive")


def _remaining_seconds(deadline: float) -> float:
    return max(0.0, deadline - time.monotonic())


def _close_transports(*transports: FramedSocket | None) -> None:
    for transport in transports:
        if transport is not None:
            transport.close()


def _client_hello(*, channel: int, session_id: bytes) -> pb.WireMessage:
    message = pb.WireMessage(
        protocol_major=_PROTOCOL_MAJOR,
        protocol_minor=_PROTOCOL_MINOR,
        session_id=session_id,
        message_sequence=1,
    )
    message.client_hello.channel = channel
    message.client_hello.requested_role = pb.SESSION_ROLE_CONTROL
    message.client_hello.client_name = "prime_hand_sdk"
    message.client_hello.client_version = _SDK_VERSION
    return message


def _require_server_hello(
    response: pb.WireMessage,
    *,
    expected_session_id: bytes | None,
) -> pb.ServerHello:
    _validate_protocol_version(response)
    payload_name = response.WhichOneof("payload")
    if payload_name == "protocol_error":
        _raise_protocol_error(response.protocol_error)
    if payload_name != "server_hello":
        raise ProtocolMismatchError(
            f"expected ServerHello, received {payload_name or 'an empty message'}"
        )
    if (
        expected_session_id is not None
        and bytes(response.session_id) != expected_session_id
    ):
        raise ProtocolMismatchError(
            "Telemetry ServerHello session_id does not match Control"
        )
    return response.server_hello


def _validate_protocol_version(response: pb.WireMessage) -> None:
    if (response.protocol_major, response.protocol_minor) != (
        _PROTOCOL_MAJOR,
        _PROTOCOL_MINOR,
    ):
        raise ProtocolMismatchError(
            "Runtime uses incompatible protocol "
            f"{response.protocol_major}.{response.protocol_minor}; expected 2.3"
        )


def _telemetry_frame_from_wire(wire: pb.TelemetryFrame) -> TelemetryFrame:
    control_level = (
        None
        if wire.control_level == pb.CONTROL_LEVEL_UNSPECIFIED
        else _control_level_from_wire(wire.control_level)
    )
    return TelemetryFrame(
        sequence=wire.sequence,
        data_subscribed=wire.data_subscribed,
        runtime_time_us=wire.runtime_time_us,
        runtime_state=_runtime_state_from_wire(wire.runtime_state),
        control_mode=_control_mode_from_wire(wire.control_mode, allow_unspecified=True),
        control_level=control_level,
        joints=tuple(
            JointTelemetry(
                index=joint.index,
                position_deg=joint.position_deg,
                velocity_deg_s=joint.velocity_deg_s,
                target_deg=joint.target_deg,
                online=joint.online,
                trusted=joint.trusted,
                control_mode=_control_mode_from_wire(
                    joint.control_mode, allow_unspecified=True
                ),
                control_level=(
                    None
                    if joint.control_level == pb.CONTROL_LEVEL_UNSPECIFIED
                    else _control_level_from_wire(joint.control_level)
                ),
            )
            for joint in wire.joints
        ),
        motors=tuple(
            MotorTelemetry(
                index=motor.index,
                position_rad=motor.position_rad,
                velocity_rad_s=motor.velocity_rad_s,
                current_a=motor.current_a,
                filtered_current_a=motor.filtered_current_a,
                current_command_a=(
                    motor.current_command_a if motor.current_command_a_valid else None
                ),
            )
            for motor in wire.motors
        ),
        encoders=tuple(
            EncoderTelemetry(
                index=encoder.index,
                active=encoder.active,
                link_state=_encoder_link_state_from_wire(encoder.link_state),
                frame_count=encoder.frame_count,
                last_error=encoder.last_error,
            )
            for encoder in wire.encoders
        ),
        faults=tuple(
            FaultInfo(
                code=fault.code,
                source=fault.source,
                description=fault.description,
                joint_indices=tuple(fault.joint_indices),
                motor_indices=tuple(fault.motor_indices),
                latched=fault.latched,
            )
            for fault in wire.faults
        ),
        per_joint_control=wire.per_joint_control,
        status=_status_from_wire(wire.status),
        target_receipt=TargetReceipt(
            wire.target_receipt.profile_id,
            wire.target_receipt.seen_sequence,
            wire.target_receipt.accepted_sequence,
            wire.target_receipt.executing_sequence,
            wire.target_receipt.rejection_reason,
            wire.target_receipt.seen_profile_id,
        ),
        joint_subscription_id=wire.joint_subscription_id,
        subscriptions=tuple(StreamStatus("joint" if item.kind == 0 else "skin", item.subscription_id, item.request_id, item.readiness_epoch,
            list(SubscriptionPhase)[item.phase] if 0 <= item.phase < len(SubscriptionPhase) else SubscriptionPhase.UNKNOWN,
            list(SubscriptionError)[item.error] if 0 <= item.error < len(SubscriptionError) else SubscriptionError.REVOKED) for item in wire.subscriptions),
        skin_status=(SkinStatus(
            installed=wire.skin_status.installed,
            palm_installed=(wire.skin_status.palm_installed if wire.skin_status.HasField("palm_installed") else None),
            data_port=wire.skin_status.data_port,
            protocol_major=wire.skin_status.protocol_major,
            protocol_minor=wire.skin_status.protocol_minor,
            layout_id=wire.skin_status.layout_id,
            hand_side=wire.skin_status.hand_side,
            schema_sha256=bytes(wire.skin_status.schema_sha256),
            point_count=wire.skin_status.point_count,
            target_period_us=wire.skin_status.target_period_us,
            source_stale=wire.skin_status.source_stale,
            channels=tuple(SkinChannel(c.id, c.status, c.mask, c.errorcode,
                c.rx_ns if c.HasField("rx_ns") else None) for c in wire.skin_status.channels),
        ) if wire.HasField("skin_status") else None),
        initialization=InitializationTelemetry(
            state=_initialization_state_from_wire(wire.initialization.state),
            active=wire.initialization.active,
            can_start=wire.initialization.can_start,
            message=wire.initialization.message,
            error=wire.initialization.error,
            request_id=wire.initialization.request_id,
            task_id=wire.initialization.task_id,
        ),
    )


def _runtime_state_from_wire(state: int) -> RuntimeState:
    mapping = {
        pb.RUNTIME_STATE_INITIALIZING: RuntimeState.INITIALIZING,
        pb.RUNTIME_STATE_WAITING_FOR_HARDWARE: RuntimeState.WAITING_FOR_HARDWARE,
        pb.RUNTIME_STATE_STOPPED: RuntimeState.STOPPED,
        pb.RUNTIME_STATE_READY: RuntimeState.READY,
        pb.RUNTIME_STATE_RUNNING: RuntimeState.RUNNING,
        pb.RUNTIME_STATE_FAULT: RuntimeState.FAULT,
        pb.RUNTIME_STATE_EMERGENCY_STOP: RuntimeState.EMERGENCY_STOP,
    }
    try:
        return mapping[state]
    except KeyError as error:
        raise ProtocolMismatchError(
            f"Runtime reported unsupported state {state}"
        ) from error


def _encoder_link_state_from_wire(state: int) -> EncoderLinkState:
    mapping = {
        pb.ENCODER_LINK_STATE_UNSPECIFIED: EncoderLinkState.UNSPECIFIED,
        pb.ENCODER_LINK_ONLINE: EncoderLinkState.ONLINE,
        pb.ENCODER_LINK_PARTIAL: EncoderLinkState.PARTIAL,
        pb.ENCODER_LINK_OFFLINE: EncoderLinkState.OFFLINE,
    }
    try:
        return mapping[state]
    except KeyError as error:
        raise ProtocolMismatchError(
            f"Runtime reported unsupported encoder link state {state}"
        ) from error


def _initialization_state_from_wire(state: int) -> InitializationState:
    mapping = {
        pb.INITIALIZATION_STATE_UNSPECIFIED: InitializationState.UNSPECIFIED,
        pb.INITIALIZATION_STATE_IDLE: InitializationState.IDLE,
        pb.INITIALIZATION_STATE_RUNNING: InitializationState.RUNNING,
        pb.INITIALIZATION_STATE_HOLDING: InitializationState.HOLDING,
        pb.INITIALIZATION_STATE_COMPLETED: InitializationState.COMPLETED,
        pb.INITIALIZATION_STATE_ABORTED: InitializationState.ABORTED,
        pb.INITIALIZATION_STATE_FAULT: InitializationState.FAULT,
    }
    try:
        return mapping[state]
    except KeyError as error:
        raise ProtocolMismatchError(
            f"Runtime reported unsupported initialization state {state}"
        ) from error


def _validate_session_message(response: pb.WireMessage, session_id: bytes) -> None:
    _validate_protocol_version(response)
    if bytes(response.session_id) != session_id:
        raise ProtocolMismatchError(
            "Runtime Control response session_id does not match"
        )


def _validate_heartbeat_parameters(device_info: DeviceInfo) -> None:
    period = device_info.heartbeat_period_ms
    timeout = device_info.heartbeat_timeout_ms
    if period <= 0 or timeout <= 0 or period >= timeout:
        raise ProtocolMismatchError(
            "Runtime returned invalid heartbeat parameters "
            f"period={period}ms timeout={timeout}ms"
        )


def _raise_operation_error(status: pb.OperationStatus, fallback: str) -> None:
    if status.ok:
        return
    detail = status.detail or fallback
    code = status.error_code
    mapping = {
        pb.ERROR_CODE_INVALID_STATE: InvalidStateError,
        pb.ERROR_CODE_NOT_READY: InvalidStateError,
        pb.ERROR_CODE_FAULT_ACTIVE: HandFaultError,
        pb.ERROR_CODE_EMERGENCY_STOP_ACTIVE: EmergencyStopError,
        pb.ERROR_CODE_INVALID_ARGUMENT: InvalidTargetError,
        pb.ERROR_CODE_IP_INVALID: InvalidTargetError,
        pb.ERROR_CODE_DEVICE_BUSY: RequestRejectedError,
        pb.ERROR_CODE_PERMISSION_DENIED: RequestRejectedError,
        pb.ERROR_CODE_IP_PERSISTENCE_FAILED: RequestRejectedError,
        pb.ERROR_CODE_INTERNAL: RequestRejectedError,
        pb.ERROR_CODE_PROTOCOL_MISMATCH: ProtocolMismatchError,
        pb.ERROR_CODE_SESSION_INVALID: ConnectionLostError,
    }
    exception = mapping.get(code, HandConnectionError)(detail)
    exception.error_code = code
    raise exception


def _raise_protocol_error(error: pb.ProtocolError, *, business=False) -> None:
    detail = error.status.detail or "Runtime rejected the protocol message"
    if business:
        try:
            _raise_operation_error(error.status, detail)
        except HandError as exception:
            exception.request_id = error.request_id
            raise
        raise ProtocolMismatchError("ProtocolError unexpectedly marked success")
    error_type = HandConnectionError
    if error.status.error_code == pb.ERROR_CODE_DEVICE_BUSY:
        error_type = DeviceBusyError
    elif error.status.error_code == pb.ERROR_CODE_PROTOCOL_MISMATCH:
        error_type = ProtocolMismatchError
    exception = error_type(detail)
    exception.request_id = error.request_id
    exception.error_code = error.status.error_code
    raise exception


def _device_info_from_hello(hello: pb.ServerHello) -> DeviceInfo:
    return DeviceInfo(
        model=hello.device.model,
        serial=hello.device.serial,
        hardware_version=hello.device.hardware_version,
        joints=tuple(
            JointInfo(
                index=joint.index,
                name=joint.name,
                min_position_deg=joint.min_position_deg,
                max_position_deg=joint.max_position_deg,
            )
            for joint in hello.device.joints
        ),
        supported_control_modes=tuple(
            _control_mode_from_wire(mode)
            for mode in hello.device.supported_control_modes
            if mode != pb.CONTROL_MODE_UNSPECIFIED
        ),
        supported_control_levels=tuple(
            _control_level_from_wire(level)
            for level in hello.device.supported_control_levels
            if level != pb.CONTROL_LEVEL_UNSPECIFIED
        ),
        supports_per_joint_control=hello.device.supports_per_joint_control,
        supports_system_operations=hello.device.supports_system_operations,
        supports_layered_status=hello.device.supports_layered_status,
        supports_target_receipts=hello.device.supports_target_receipts,
        supports_explicit_telemetry=hello.device.supports_explicit_telemetry,
        supports_data_streams=hello.device.supports_data_streams,
        status_max_age_ms=hello.status_max_age_ms or 100,
        runtime_version=hello.runtime_version,
        protocol_version=ProtocolVersion(_PROTOCOL_MAJOR, _PROTOCOL_MINOR),
        active_ipv4=hello.active_ipv4,
        prefix_length=hello.prefix_length,
        network_reset_button_available=hello.network_reset_button_available,
        telemetry_hz=hello.telemetry_hz,
        heartbeat_period_ms=hello.heartbeat_period_ms,
        heartbeat_timeout_ms=hello.heartbeat_timeout_ms,
    )


def _control_mode_from_wire(
    mode: int, *, allow_unspecified: bool = False
) -> JointControlMode | None:
    if mode == pb.CONTROL_MODE_UNSPECIFIED and allow_unspecified:
        return None
    mapping = {
        pb.CONTROL_MODE_OPEN_LOOP: JointControlMode.OPEN_LOOP,
        pb.CONTROL_MODE_PID1: JointControlMode.PID1,
        pb.CONTROL_MODE_PID2: JointControlMode.PID2,
    }
    try:
        return mapping[mode]
    except KeyError as error:
        raise ProtocolMismatchError(
            f"Runtime reported unsupported control mode {mode}"
        ) from error


def _control_level_from_wire(level: int) -> ControlLevel:
    mapping = {
        pb.CONTROL_LEVEL_LOW: ControlLevel.LOW,
        pb.CONTROL_LEVEL_MEDIUM: ControlLevel.MEDIUM,
        pb.CONTROL_LEVEL_HIGH: ControlLevel.HIGH,
    }
    try:
        return mapping[level]
    except KeyError as error:
        raise ProtocolMismatchError(
            f"Runtime reported unsupported control level {level}"
        ) from error


def _validate_ipv4(ip: str) -> str:
    if not isinstance(ip, str):
        raise TypeError("ip must be an IPv4 string")
    try:
        return str(ipaddress.IPv4Address(ip))
    except ipaddress.AddressValueError as error:
        raise ValueError(f"ip must be a valid IPv4 address, got {ip!r}") from error


def _validate_port(name: str, port: int) -> int:
    if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65535:
        raise ValueError(f"{name} must be an integer in [1, 65535]")
    return port


def _status_from_wire(wire):
    phases = tuple(SystemPhase)
    executions = tuple(ExecutionPhase)
    return RuntimeStatus(
        phase=(
            phases[wire.phase] if 0 <= wire.phase < len(phases) else SystemPhase.UNKNOWN
        ),
        execution_phase=(
            executions[wire.execution_phase]
            if 0 <= wire.execution_phase < len(executions)
            else ExecutionPhase.UNKNOWN
        ),
        execution_source=wire.execution_source,
        reason=wire.reason,
        valid=wire.valid,
        source_time_ns=wire.source_time_ns,
        age_ns=wire.age_ns,
        boot_id=(wire.boot_high, wire.boot_low),
        motors=HealthSummary(
            wire.motors.available_mask,
            wire.motors.valid,
            wire.motors.age_ns,
            (
                tuple(ModuleHealth)[wire.motors.health]
                if wire.motors.health < len(ModuleHealth)
                else ModuleHealth.UNKNOWN
            ),
        ),
        joints=HealthSummary(
            wire.joints.available_mask,
            wire.joints.valid,
            wire.joints.age_ns,
            (
                tuple(ModuleHealth)[wire.joints.health]
                if wire.joints.health < len(ModuleHealth)
                else ModuleHealth.UNKNOWN
            ),
        ),
        profile_id=wire.profile_id,
        accepted_target_sequence=wire.accepted_target_sequence,
        executing_target_sequence=wire.executing_target_sequence,
        control_epoch=wire.control_epoch,
        motion_permitted=wire.motion_permitted,
        readiness_epoch=wire.readiness_epoch,
        control_ready=wire.control_ready,
        preparing=wire.preparing,
        preparation_reason=OperationReason(wire.preparation_reason),
    )
