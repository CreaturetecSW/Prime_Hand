"""Public, dependency-free data models exposed by the Prime Hand SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, IntEnum


class RuntimeState(str, Enum):
    """Runtime state reported by the hand or synthesized by the SDK."""

    DISCONNECTED = "disconnected"
    INITIALIZING = "initializing"
    WAITING_FOR_HARDWARE = "waiting_for_hardware"
    STOPPED = "stopped"
    READY = "ready"
    RUNNING = "running"
    FAULT = "fault"
    EMERGENCY_STOP = "emergency_stop"
    PROTOCOL_MISMATCH = "protocol_mismatch"


class SystemPhase(str, Enum):
    UNKNOWN = "unknown"
    STARTING = "starting"
    STANDBY = "standby"
    READY = "ready"
    RUNNING = "running"
    EMERGENCY_STOP = "emergency_stop"
    OTA = "ota"
    RECOVERING = "recovering"
    FAULT = "fault"


class ExecutionPhase(str, Enum):
    UNKNOWN = "unknown"
    IDLE = "idle"
    WAITING = "waiting"
    EXECUTING = "executing"
    PAUSED = "paused"
    REBUILDING = "rebuilding"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    FAILED = "failed"


class ModuleHealth(str, Enum):
    UNKNOWN = "unknown"
    HEALTHY = "healthy"
    PARTIALLY_AVAILABLE = "partially_available"
    UNAVAILABLE = "unavailable"
    RECOVERING = "recovering"


@dataclass(frozen=True, slots=True)
class HealthSummary:
    available_mask: int = 0
    valid: bool = False
    age_ns: int = 0
    health: ModuleHealth = ModuleHealth.UNKNOWN


class OperationReason(IntEnum):
    NONE = 0
    INVALID_INPUT = 1
    SOURCE_REVOKED = 2
    NOT_PERMITTED = 3
    DEPENDENCY_UNAVAILABLE = 4
    STALE_FEEDBACK = 5
    BUSY = 6
    QUEUE_FULL = 7
    SAFETY_REJECTED = 8
    TRANSPORT_FAILURE = 9
    CONFIRMATION_TIMEOUT = 10
    INTERRUPTED = 11
    INVALID_VERSION = 12
    DEVICE_REPORTED_FAULT = 13
    EVIDENCE_GAP = 14
    FRESHNESS_TIMEOUT = 15
    INTERNAL_ERROR = 16
    UNKNOWN = 255

    @classmethod
    def _missing_(cls, value):
        return cls.UNKNOWN


@dataclass(frozen=True, slots=True)
class RuntimeStatus:
    phase: SystemPhase = SystemPhase.UNKNOWN
    execution_phase: ExecutionPhase = ExecutionPhase.UNKNOWN
    execution_source: int = 0
    reason: str = ""
    valid: bool = False
    source_time_ns: int = 0
    age_ns: int = 0
    boot_id: tuple[int, int] = (0, 0)
    motors: HealthSummary = field(default_factory=HealthSummary)
    joints: HealthSummary = field(default_factory=HealthSummary)
    profile_id: int = 0
    accepted_target_sequence: int = 0
    executing_target_sequence: int = 0
    control_epoch: int = 0
    motion_permitted: bool = False
    readiness_epoch: int = 0
    control_ready: bool = False
    preparing: bool = False
    preparation_reason: OperationReason = OperationReason.NONE


@dataclass(frozen=True, slots=True)
class TargetReceipt:
    profile_id: int = 0
    seen_sequence: int = 0
    accepted_sequence: int = 0
    executing_sequence: int = 0
    rejection_reason: str = ""
    seen_profile_id: int = 0


class JointControlMode(str, Enum):
    """Control mode used for joint targets."""

    OPEN_LOOP = "open_loop"
    PID1 = "pid1"  # FeedforwardPosition
    PID2 = "pid2"  # velocity PD


class ControlLevel(str, Enum):
    """Runtime-selected low, medium, or high control preset."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class EncoderLinkState(str, Enum):
    """Health of the joint encoder link."""

    UNSPECIFIED = "unspecified"
    ONLINE = "online"
    PARTIAL = "partial"
    OFFLINE = "offline"


class InitializationState(str, Enum):
    """Runtime-owned whole-hand initialization state."""

    UNSPECIFIED = "unspecified"
    IDLE = "idle"
    RUNNING = "running"
    HOLDING = "holding"
    COMPLETED = "completed"
    ABORTED = "aborted"
    FAULT = "fault"


@dataclass(frozen=True, slots=True)
class ProtocolVersion:
    """Public protocol major/minor version."""

    major: int = 2
    minor: int = 1


@dataclass(frozen=True, slots=True)
class JointInfo:
    """Static information for one joint; position limits are in degrees."""

    index: int
    name: str
    min_position_deg: float
    max_position_deg: float


@dataclass(frozen=True, slots=True)
class DeviceInfo:
    """Device identity and capabilities returned during the handshake."""

    model: str = ""
    serial: str = ""
    hardware_version: str = ""
    joints: tuple[JointInfo, ...] = field(default_factory=tuple)
    supported_control_modes: tuple[JointControlMode, ...] = field(default_factory=tuple)
    supported_control_levels: tuple[ControlLevel, ...] = field(default_factory=tuple)
    runtime_version: str = ""
    protocol_version: ProtocolVersion = field(default_factory=ProtocolVersion)
    active_ipv4: str = ""
    prefix_length: int = 0
    network_reset_button_available: bool = False
    telemetry_hz: int = 50
    heartbeat_period_ms: int = 250
    heartbeat_timeout_ms: int = 1000
    supports_per_joint_control: bool = False
    supports_system_operations: bool = False
    supports_layered_status: bool = False
    supports_target_receipts: bool = False
    supports_explicit_telemetry: bool = False
    supports_data_streams: bool = False
    status_max_age_ms: int = 100

    def __post_init__(self) -> None:
        object.__setattr__(self, "joints", tuple(self.joints))
        object.__setattr__(
            self,
            "supported_control_modes",
            tuple(self.supported_control_modes),
        )
        object.__setattr__(
            self,
            "supported_control_levels",
            tuple(self.supported_control_levels),
        )


@dataclass(frozen=True, slots=True)
class JointTelemetry:
    """One joint telemetry sample; all joint angles and speeds are degrees."""

    index: int
    position_deg: float
    velocity_deg_s: float
    target_deg: float
    online: bool
    trusted: bool
    control_mode: JointControlMode | None = None
    control_level: ControlLevel | None = None


@dataclass(frozen=True, slots=True)
class MotorTelemetry:
    """One motor telemetry sample; angles are radians and current is amperes."""

    index: int
    position_rad: float
    velocity_rad_s: float
    current_a: float
    filtered_current_a: float
    current_command_a: float | None


@dataclass(frozen=True, slots=True)
class EncoderTelemetry:
    """One encoder-link telemetry sample."""

    index: int
    active: bool
    link_state: EncoderLinkState
    frame_count: int
    last_error: str = ""


@dataclass(frozen=True, slots=True)
class FaultInfo:
    """Structured fault information reported by Runtime."""

    code: str
    source: str
    description: str
    joint_indices: tuple[int, ...] = field(default_factory=tuple)
    motor_indices: tuple[int, ...] = field(default_factory=tuple)
    latched: bool = False

    def __post_init__(self) -> None:
        object.__setattr__(self, "joint_indices", tuple(self.joint_indices))
        object.__setattr__(self, "motor_indices", tuple(self.motor_indices))


@dataclass(frozen=True, slots=True)
class InitializationTelemetry:
    """Status of the Runtime-owned whole-hand initialization sequence."""

    state: InitializationState = InitializationState.UNSPECIFIED
    active: bool = False
    can_start: bool = False
    message: str = ""
    error: str = ""
    request_id: int = 0
    task_id: int = 0


@dataclass(frozen=True, slots=True)
class SkinChannel:
    id: int
    status: int
    mask: int
    errorcode: int = 0
    rx_ns: int | None = None
    connection_epoch: int = 0
    sample_seq: int = 0
    device_seq: int | None = None


@dataclass(frozen=True, slots=True)
class SkinStatus:
    installed: bool = False
    palm_installed: bool | None = None
    data_port: int = 0
    protocol_major: int = 0
    protocol_minor: int = 0
    layout_id: int = 0
    hand_side: int = 0
    schema_sha256: bytes = b""
    point_count: int = 0
    target_period_us: int = 0
    source_stale: bool = True
    channels: tuple[SkinChannel, ...] = ()


@dataclass(frozen=True, slots=True)
class SkinFrame:
    sequence: int
    layout_id: int
    hand_side: int
    channels: tuple[SkinChannel, ...]
    points: bytes
    source_status: int
    boot_id: bytes = b""
    snapshot_version: int = 0
    published_ns: int = 0
    hardware_published_ns: int = 0


class SubscriptionPhase(str, Enum):
    UNKNOWN = "unknown"
    STARTING = "starting"
    ACTIVE = "active"
    STOPPING = "stopping"
    STOPPED = "stopped"
    FAILED = "failed"


class SubscriptionError(str, Enum):
    NONE = "none"
    CONFIRMATION_TIMEOUT = "confirmation_timeout"
    TRANSPORT = "transport"
    REVOKED = "revoked"


@dataclass(frozen=True, slots=True)
class StreamStatus:
    kind: str
    subscription_id: int
    request_id: int = 0
    readiness_epoch: int = 0
    phase: SubscriptionPhase = SubscriptionPhase.STARTING
    error: SubscriptionError = SubscriptionError.NONE
    valid: bool = True
    first_frame_received: bool = False
    stale: bool = True


@dataclass(frozen=True, slots=True)
class JointFrame:
    sequence: int
    subscription_id: int
    readiness_epoch: int
    joints: tuple[JointTelemetry, ...]
    encoders: tuple[EncoderTelemetry, ...]


@dataclass(frozen=True, slots=True)
class TelemetryFrame:
    """One immutable 50 Hz telemetry snapshot."""

    sequence: int
    runtime_time_us: int
    runtime_state: RuntimeState
    control_mode: JointControlMode | None
    control_level: ControlLevel | None
    joints: tuple[JointTelemetry, ...] = field(default_factory=tuple)
    motors: tuple[MotorTelemetry, ...] = field(default_factory=tuple)
    encoders: tuple[EncoderTelemetry, ...] = field(default_factory=tuple)
    faults: tuple[FaultInfo, ...] = field(default_factory=tuple)
    status: RuntimeStatus = field(default_factory=RuntimeStatus)
    target_receipt: TargetReceipt = field(default_factory=TargetReceipt)
    data_subscribed: bool = False
    per_joint_control: bool = False
    initialization: InitializationTelemetry = field(
        default_factory=InitializationTelemetry
    )
    skin_status: SkinStatus | None = None
    subscriptions: tuple[StreamStatus, ...] = ()
    joint_subscription_id: int = 0

    def __post_init__(self) -> None:
        object.__setattr__(self, "joints", tuple(self.joints))
        object.__setattr__(self, "motors", tuple(self.motors))
        object.__setattr__(self, "encoders", tuple(self.encoders))
        object.__setattr__(self, "faults", tuple(self.faults))


@dataclass(frozen=True, slots=True)
class HandState:
    """Immutable state snapshot available independently of telemetry delivery."""

    runtime_state: RuntimeState = RuntimeState.DISCONNECTED
    control_mode: JointControlMode | None = None
    control_level: ControlLevel | None = None
    status: RuntimeStatus = field(default_factory=RuntimeStatus)
    target_receipt: TargetReceipt = field(default_factory=TargetReceipt)
    data_subscribed: bool = False
    stale: bool = True
    sequence: int = 0
    faults: tuple[FaultInfo, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        object.__setattr__(self, "faults", tuple(self.faults))
