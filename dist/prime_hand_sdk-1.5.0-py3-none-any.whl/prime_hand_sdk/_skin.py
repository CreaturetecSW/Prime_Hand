"""Session-bound raw 19103 skin stream; filtering belongs to the consumer."""
from __future__ import annotations

from collections import deque
import socket
import threading
import time
from typing import Callable

from google.protobuf.message import DecodeError

from ._framing import FrameDecoder, FrameError, encode_frame
from ._protocol import prime_hand_skin_v1_pb2 as pb
from ._protocol.skin_schema import SCHEMA_SHA256
from .errors import HandConnectionError, HandTimeoutError, ProtocolMismatchError
from .models import SkinChannel, SkinFrame
from ._streams import DataStream, timeout_value


class SkinStream(DataStream):
    """One bounded raw skin subscription, owned by its PrimeHand session."""

    def __init__(self, sock: socket.socket, subscription_id=0, readiness_epoch=0) -> None:
        super().__init__("skin", subscription_id, readiness_epoch)
        self._socket = sock
        self._decoder = FrameDecoder(max_frame_size=4096)
        self._pending: deque[bytes] = deque()
        self._closed = False
        self._sequence = 0
        self.hand_side = 0

    @classmethod
    def connect(cls, ip: str, port: int, session_id: bytes, timeout: float, *, subscription_id=0, readiness_epoch=0) -> SkinStream:
        if len(session_id) != 16 or timeout <= 0:
            raise ValueError("skin session id or timeout is invalid")
        try:
            sock = socket.create_connection((ip, port), timeout=timeout)
        except (OSError, TimeoutError) as error:
            raise HandConnectionError("could not connect to Runtime skin endpoint") from error
        stream = cls(sock, subscription_id, readiness_epoch)
        try:
            request = pb.SkinWireMessage(protocol_major=1, protocol_minor=2, message_sequence=1)
            request.client_hello.layout_id = 2
            request.client_hello.client_name = "Prime Hand SDK"
            request.client_hello.session_id = session_id
            request.client_hello.subscription_id = subscription_id
            request.client_hello.readiness_epoch = readiness_epoch
            sock.settimeout(timeout)
            sock.sendall(encode_frame(request.SerializeToString()))
            message = stream._receive(timeout)
            if message is None:
                raise HandTimeoutError("skin handshake timed out")
            if message.WhichOneof("payload") != "server_hello":
                raise ProtocolMismatchError("skin handshake did not return ServerHello")
            hello = message.server_hello
            if (message.protocol_major, message.protocol_minor) != (1, 2) or hello.layout_id != 2 or \
               hello.hand_side not in (1, 2) or hello.point_count != 1542 or \
               hello.schema_sha256 != SCHEMA_SHA256 or hello.data_format != "raw_matrices_u8_untared":
                raise ProtocolMismatchError("incompatible skin protocol or schema")
            if hello.subscription_id != subscription_id or hello.readiness_epoch != readiness_epoch:
                raise ProtocolMismatchError("skin stream binding identity mismatch")
            stream._max_age = max(0.1, 2*hello.target_period_us/1_000_000)
            stream.hand_side = hello.hand_side
            stream._thread = threading.Thread(target=stream._run, name="prime-hand-skin-receive", daemon=True)
            stream._thread.start()
            return stream
        except Exception:
            stream.close(notify=False)
            raise

    def _receive(self, timeout: float):
        deadline = time.monotonic() + timeout
        while not self._pending:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return None
            try:
                self._socket.settimeout(remaining)
                chunk = self._socket.recv(8192)
            except socket.timeout:
                return None
            except OSError as error:
                raise HandConnectionError("skin connection lost") from error
            if not chunk:
                raise HandConnectionError("Runtime closed skin connection")
            try:
                self._pending.extend(self._decoder.feed(chunk))
            except FrameError as error:
                raise ProtocolMismatchError("invalid skin frame length") from error
        try:
            return pb.SkinWireMessage.FromString(self._pending.popleft())
        except DecodeError as error:
            raise ProtocolMismatchError("invalid skin protobuf frame") from error

    def _read_frame(self, timeout: float = 1.0) -> SkinFrame | None:
        if timeout <= 0:
            raise ValueError("timeout must be positive")
        if self._closed:
            raise HandConnectionError("skin stream is closed")
        message = self._receive(timeout)
        if message is None:
            return None
        if (message.protocol_major, message.protocol_minor) != (1, 2) or message.WhichOneof("payload") != "skin_frame":
            raise ProtocolMismatchError("unexpected skin stream message")
        frame = message.skin_frame
        if (message.message_sequence <= self._sequence or frame.layout_id != 2 or
                frame.hand_side != self.hand_side or len(frame.points) != 1542 or
                len(frame.channels) != 6 or {c.id for c in frame.channels} != set(range(6))):
            raise ProtocolMismatchError("invalid skin frame identity or layout")
        self._sequence = message.message_sequence
        channels = tuple(SkinChannel(c.id, c.status, c.mask, c.errorcode,
            c.sample.rx_ns if c.HasField("sample") else None,
            c.sample.connection_epoch if c.HasField("sample") else 0,
            c.sample.sample_seq if c.HasField("sample") else 0,
            c.sample.device_seq if c.HasField("sample") and c.sample.HasField("device_seq") else None)
            for c in frame.channels)
        return SkinFrame(message.message_sequence, frame.layout_id, frame.hand_side, channels,
            bytes(frame.points), frame.source_status, bytes(frame.boot_id), frame.snapshot_version,
            frame.published_ns, frame.hardware_published_ns)

    def _run(self):
        try:
            while not self._closed:
                frame = self._read_frame(0.1)
                if frame is not None:
                    self._put(frame)
        except HandConnectionError as error:
            if not self._closed:
                self._invalidate(error)

    def close(self, timeout: float = 2.0, *, notify: bool = True) -> None:
        timeout_value(timeout)
        if notify:
            super().close(timeout)
        else:
            self._finish()

    def _finish(self):
        super()._finish()
        try:
            self._socket.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        self._socket.close()
        thread = getattr(self, "_thread", None)
        if thread is not None and thread is not threading.current_thread():
            thread.join(0.2)
